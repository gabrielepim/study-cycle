import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, json, boolean, date, float } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Study Cycle Progress
export const cycleProgress = mysqlTable("cycleProgress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  currentSessionId: int("currentSessionId").default(1).notNull(),
  completedSessions: json("completedSessions").$type<number[]>().default([]).notNull(),
  totalSessions: int("totalSessions").default(9).notNull(),
  cycleStartDate: timestamp("cycleStartDate").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CycleProgress = typeof cycleProgress.$inferSelect;
export type InsertCycleProgress = typeof cycleProgress.$inferInsert;

// Productivity Records
export const productivityRecords = mysqlTable("productivityRecords", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  sessionId: int("sessionId").notNull(),
  sessionName: varchar("sessionName", { length: 255 }).notNull(),
  date: timestamp("date").defaultNow().notNull(),
  questionsAttempted: int("questionsAttempted").notNull(),
  questionsCorrect: int("questionsCorrect").notNull(),
  successRate: decimal("successRate", { precision: 5, scale: 2 }).notNull(),
  duration: int("duration").notNull(),
  focus: mysqlEnum("focus", ["Teoria", "Questões", "Revisão"]),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ProductivityRecord = typeof productivityRecords.$inferSelect;
export type InsertProductivityRecord = typeof productivityRecords.$inferInsert;

// Error Entries (Caderno de Erros)
export const errorEntries = mysqlTable("errorEntries", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  subject: varchar("subject", { length: 255 }).notNull(),
  description: text("description").notNull(),
  errorType: mysqlEnum("errorType", ["Lei Seca", "Atenção", "Teoria"]).notNull(),
  category: mysqlEnum("category", ["Legislação", "Geral"]).notNull(),
  date: timestamp("date").defaultNow().notNull(),
  sessionId: int("sessionId"),
  lastPage: varchar("lastPage", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ErrorEntry = typeof errorEntries.$inferSelect;
export type InsertErrorEntry = typeof errorEntries.$inferInsert;

// Editorial Topics
export const editorialTopics = mysqlTable("editorialTopics", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  subject: varchar("subject", { length: 255 }).notNull(),
  topic: varchar("topic", { length: 255 }).notNull(),
  subtopics: json("subtopics").$type<Array<{
    id: string;
    name: string;
    theory: boolean;
    review: boolean;
    questions: boolean;
    reviewDate?: string;
  }>>().default([]).notNull(),
  lastReviewDate: timestamp("lastReviewDate"),
  freshness: mysqlEnum("freshness", ["green", "yellow", "red"]).default("red").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type EditorialTopic = typeof editorialTopics.$inferSelect;
export type InsertEditorialTopic = typeof editorialTopics.$inferInsert;

// Weekend Blocks
export const weekendBlocks = mysqlTable("weekendBlocks", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  date: date("date").notNull(),
  type: mysqlEnum("type", ["Discursiva", "Revisão Geral"]).notNull(),
  duration: int("duration").notNull(),
  completed: boolean("completed").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WeekendBlock = typeof weekendBlocks.$inferSelect;
export type InsertWeekendBlock = typeof weekendBlocks.$inferInsert;

// Arguments/Citations
export const argumentsTable = mysqlTable("arguments", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  subject: mysqlEnum("subject", ["Relações Públicas", "Legislação", "Geral"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  tags: json("tags").$type<string[]>().default([]).notNull(),
  createdDate: timestamp("createdDate").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Argument = typeof argumentsTable.$inferSelect;
export type InsertArgument = typeof argumentsTable.$inferInsert;

// Exam Questions
export const examQuestions = mysqlTable("examQuestions", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  organ: varchar("organ", { length: 255 }),
  banca: varchar("banca", { length: 255 }),
  year: int("year"),
  subject: varchar("subject", { length: 255 }).notNull(),
  enunciation: text("enunciation").notNull(),
  alternatives: json("alternatives").$type<{
    a: string;
    b: string;
    c: string;
    d: string;
    e: string;
  }>().notNull(),
  correctAnswer: mysqlEnum("correctAnswer", ["a", "b", "c", "d", "e"]).notNull(),
  userAnswer: mysqlEnum("userAnswer", ["a", "b", "c", "d", "e"]),
  questionType: mysqlEnum("questionType", ["Múltipla Escolha", "Verdadeiro/Falso", "Discursiva"]).notNull(),
  errorTags: json("errorTags").$type<("Lei Seca" | "Atenção" | "Teoria" | "Pegadinha da Banca")[]>().default([]).notNull(),
  comments: text("comments"),
  isRevealed: boolean("isRevealed").default(false).notNull(),
  date: timestamp("date").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ExamQuestion = typeof examQuestions.$inferSelect;
export type InsertExamQuestion = typeof examQuestions.$inferInsert;

// SRS Errors (Spaced Repetition System)
export const srsErrors = mysqlTable("srsErrors", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  
  // Base fields
  subject: varchar("subject", { length: 255 }).notNull(),
  description: text("description").notNull(),
  
  // IA fields
  question: text("question"),
  options: json("options").$type<{ a: string; b: string; c: string; d: string; e: string }>()
    .default({ a: "", b: "", c: "", d: "", e: "" })
    .notNull(),
  answer: varchar("answer", { length: 10 }),
  explanation: text("explanation"),
  generated: boolean("generated").default(false).notNull(),
  
  // SRS fields
  interval: int("interval").default(1).notNull(),
  easeFactor: float("easeFactor").default(2.5).notNull(),
  repetitions: int("repetitions").default(0).notNull(),
  nextReviewDate: timestamp("nextReviewDate").defaultNow().notNull(),
  lastReviewDate: timestamp("lastReviewDate"),
  
  // Priority fields
  difficulty: float("difficulty").default(0.5).notNull(),
  timesSeen: int("timesSeen").default(0).notNull(),
  
  // Gamification
  xpReward: int("xpReward").default(10).notNull(),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SrsError = typeof srsErrors.$inferSelect;
export type InsertSrsError = typeof srsErrors.$inferInsert;

// Gamification Stats
export const gamificationStats = mysqlTable("gamificationStats", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull().unique(),
  xp: int("xp").default(0).notNull(),
  level: int("level").default(1).notNull(),
  streak: int("streak").default(0).notNull(),
  longestStreak: int("longestStreak").default(0).notNull(),
  lastStudyDate: date("lastStudyDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type GamificationStats = typeof gamificationStats.$inferSelect;
export type InsertGamificationStats = typeof gamificationStats.$inferInsert;

// Study Calendar
export const studyCalendar = mysqlTable("studyCalendar", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: int("userId").notNull(),
  date: date("date").notNull(),
  studied: boolean("studied").default(false).notNull(),
  duration: int("duration").default(0).notNull(),
  sessionType: mysqlEnum("sessionType", ["Ciclo", "Discursiva", "Revisão Geral"]),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type StudyCalendarDay = typeof studyCalendar.$inferSelect;
export type InsertStudyCalendarDay = typeof studyCalendar.$inferInsert;

// Relations
export const usersRelations = relations(users, ({ many, one }) => ({
  cycleProgress: many(cycleProgress),
  productivityRecords: many(productivityRecords),
  errorEntries: many(errorEntries),
  editorialTopics: many(editorialTopics),
  weekendBlocks: many(weekendBlocks),
  arguments: many(argumentsTable),
  examQuestions: many(examQuestions),
  studyCalendar: many(studyCalendar),
  srsErrors: many(srsErrors),
  gamificationStats: one(gamificationStats),
}));

export const cycleProgressRelations = relations(cycleProgress, ({ one }) => ({
  user: one(users, {
    fields: [cycleProgress.userId],
    references: [users.id],
  }),
}));

export const productivityRecordsRelations = relations(productivityRecords, ({ one }) => ({
  user: one(users, {
    fields: [productivityRecords.userId],
    references: [users.id],
  }),
}));

export const errorEntriesRelations = relations(errorEntries, ({ one }) => ({
  user: one(users, {
    fields: [errorEntries.userId],
    references: [users.id],
  }),
}));

export const editorialTopicsRelations = relations(editorialTopics, ({ one }) => ({
  user: one(users, {
    fields: [editorialTopics.userId],
    references: [users.id],
  }),
}));

export const weekendBlocksRelations = relations(weekendBlocks, ({ one }) => ({
  user: one(users, {
    fields: [weekendBlocks.userId],
    references: [users.id],
  }),
}));

export const argumentsRelations = relations(argumentsTable, ({ one }) => ({
  user: one(users, {
    fields: [argumentsTable.userId],
    references: [users.id],
  }),
}));

export const examQuestionsRelations = relations(examQuestions, ({ one }) => ({
  user: one(users, {
    fields: [examQuestions.userId],
    references: [users.id],
  }),
}));

export const studyCalendarRelations = relations(studyCalendar, ({ one }) => ({
  user: one(users, {
    fields: [studyCalendar.userId],
    references: [users.id],
  }),
}));

export const srsErrorsRelations = relations(srsErrors, ({ one }) => ({
  user: one(users, {
    fields: [srsErrors.userId],
    references: [users.id],
  }),
}));

export const gamificationStatsRelations = relations(gamificationStats, ({ one }) => ({
  user: one(users, {
    fields: [gamificationStats.userId],
    references: [users.id],
  }),
}));
