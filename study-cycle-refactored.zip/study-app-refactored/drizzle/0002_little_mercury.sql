CREATE TABLE `gamificationStats` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`xp` int NOT NULL DEFAULT 0,
	`level` int NOT NULL DEFAULT 1,
	`streak` int NOT NULL DEFAULT 0,
	`longestStreak` int NOT NULL DEFAULT 0,
	`lastStudyDate` date,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `gamificationStats_id` PRIMARY KEY(`id`),
	CONSTRAINT `gamificationStats_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `srsErrors` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`subject` varchar(255) NOT NULL,
	`description` text NOT NULL,
	`question` text,
	`options` json NOT NULL DEFAULT ('{"a":"","b":"","c":"","d":"","e":""}'),
	`answer` varchar(10),
	`explanation` text,
	`generated` boolean NOT NULL DEFAULT false,
	`interval` int NOT NULL DEFAULT 1,
	`easeFactor` float NOT NULL DEFAULT 2.5,
	`repetitions` int NOT NULL DEFAULT 0,
	`nextReviewDate` timestamp NOT NULL DEFAULT (now()),
	`lastReviewDate` timestamp,
	`difficulty` float NOT NULL DEFAULT 0.5,
	`timesSeen` int NOT NULL DEFAULT 0,
	`xpReward` int NOT NULL DEFAULT 10,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `srsErrors_id` PRIMARY KEY(`id`)
);
