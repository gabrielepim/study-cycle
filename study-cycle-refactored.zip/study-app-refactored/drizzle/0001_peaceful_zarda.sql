CREATE TABLE `arguments` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`subject` enum('Relações Públicas','Legislação','Geral') NOT NULL,
	`title` varchar(255) NOT NULL,
	`content` text NOT NULL,
	`tags` json NOT NULL DEFAULT ('[]'),
	`createdDate` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `arguments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cycleProgress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`currentSessionId` int NOT NULL DEFAULT 1,
	`completedSessions` json NOT NULL DEFAULT ('[]'),
	`totalSessions` int NOT NULL DEFAULT 9,
	`cycleStartDate` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cycleProgress_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `editorialTopics` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`subject` varchar(255) NOT NULL,
	`topic` varchar(255) NOT NULL,
	`subtopics` json NOT NULL DEFAULT ('[]'),
	`lastReviewDate` timestamp,
	`freshness` enum('green','yellow','red') NOT NULL DEFAULT 'red',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `editorialTopics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `errorEntries` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`subject` varchar(255) NOT NULL,
	`description` text NOT NULL,
	`errorType` enum('Lei Seca','Atenção','Teoria') NOT NULL,
	`category` enum('Legislação','Geral') NOT NULL,
	`date` timestamp NOT NULL DEFAULT (now()),
	`sessionId` int,
	`lastPage` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `errorEntries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `examQuestions` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`organ` varchar(255),
	`banca` varchar(255),
	`year` int,
	`subject` varchar(255) NOT NULL,
	`enunciation` text NOT NULL,
	`alternatives` json NOT NULL,
	`correctAnswer` enum('a','b','c','d','e') NOT NULL,
	`userAnswer` enum('a','b','c','d','e'),
	`questionType` enum('Múltipla Escolha','Verdadeiro/Falso','Discursiva') NOT NULL,
	`errorTags` json NOT NULL DEFAULT ('[]'),
	`comments` text,
	`isRevealed` boolean NOT NULL DEFAULT false,
	`date` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `examQuestions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `productivityRecords` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`sessionId` int NOT NULL,
	`sessionName` varchar(255) NOT NULL,
	`date` timestamp NOT NULL DEFAULT (now()),
	`questionsAttempted` int NOT NULL,
	`questionsCorrect` int NOT NULL,
	`successRate` decimal(5,2) NOT NULL,
	`duration` int NOT NULL,
	`focus` enum('Teoria','Questões','Revisão'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `productivityRecords_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `studyCalendar` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`date` date NOT NULL,
	`studied` boolean NOT NULL DEFAULT false,
	`duration` int NOT NULL DEFAULT 0,
	`sessionType` enum('Ciclo','Discursiva','Revisão Geral'),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `studyCalendar_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `weekendBlocks` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`date` date NOT NULL,
	`type` enum('Discursiva','Revisão Geral') NOT NULL,
	`duration` int NOT NULL,
	`completed` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `weekendBlocks_id` PRIMARY KEY(`id`)
);
