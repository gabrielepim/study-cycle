import React, { useState, useEffect, useRef, useCallback } from "react";
import Layout from "@/components/Layout";
import SessionBriefing from "@/components/SessionBriefing";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useStudyCycle } from "@/contexts/StudyCycleContext";
import { STUDY_SESSIONS, TIMER_DURATION } from "@/types";
import {
  Play, Pause, Square, RotateCcw, CheckCircle2, Clock,
  AlertCircle, Zap,
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

// ── Persistence keys ──────────────────────────────────────────
const LS_TIMER_KEY  = "sc:timer:startEpoch";   // epoch ms when timer started (or 0 = paused)
const LS_ELAPSED    = "sc:timer:elapsed";       // total elapsed seconds before current segment
const LS_RUNNING    = "sc:timer:running";

function loadTimerState() {
  const elapsed  = parseInt(localStorage.getItem(LS_ELAPSED) || "0", 10) || 0;
  const running  = localStorage.getItem(LS_RUNNING) === "true";
  const epoch    = parseInt(localStorage.getItem(LS_TIMER_KEY) || "0", 10) || 0;
  return { elapsed, running, epoch };
}

function saveTimerState(elapsed: number, running: boolean, epoch: number) {
  localStorage.setItem(LS_ELAPSED, String(elapsed));
  localStorage.setItem(LS_RUNNING, String(running));
  localStorage.setItem(LS_TIMER_KEY, String(epoch));
}

function clearTimerState() {
  localStorage.removeItem(LS_ELAPSED);
  localStorage.removeItem(LS_RUNNING);
  localStorage.removeItem(LS_TIMER_KEY);
}

// ── Format helper ─────────────────────────────────────────────
function formatTime(seconds: number) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

// ── Quality color ─────────────────────────────────────────────
function qualityInfo(seconds: number): { cls: string; label: string; emoji: string } {
  const hrs = seconds / 3600;
  if (hrs < 1)    return { cls: "status-red",    label: "< 1h — Repita essa sessão!",    emoji: "🔴" };
  if (hrs < 2)    return { cls: "status-yellow", label: "1h–2h — Bom, pode melhorar",    emoji: "🟡" };
  return            { cls: "status-green",  label: "≥ 2h — Excelente sessão! 🎉",  emoji: "🟢" };
}

export default function StudyCycle() {
  const { cycleProgress, currentSession, completeSession, addProductivityRecord } = useStudyCycle();
  const addProductivity = trpc.productivity.addRecord.useMutation().mutateAsync;

  // ── Timer state (restored from localStorage) ─────────────────
  const [elapsed, setElapsed] = useState(0);    // seconds accumulated
  const [running, setRunning] = useState(false);
  const epochRef   = useRef(0);                 // when current segment started
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ── UI state ──────────────────────────────────────────────────
  const [showBriefing, setShowBriefing]     = useState(false);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [questionsAttempted, setQuestionsAttempted] = useState("");
  const [questionsCorrect,   setQuestionsCorrect]   = useState("");
  const [selectedSubject, setSelectedSubject]       = useState("");

  // ── Restore on mount ──────────────────────────────────────────
  useEffect(() => {
    const { elapsed: e, running: r, epoch } = loadTimerState();
    if (r && epoch > 0) {
      const extra = Math.floor((Date.now() - epoch) / 1000);
      const restored = e + extra;
      setElapsed(restored);
      epochRef.current = epoch;
      setRunning(true);
    } else {
      setElapsed(e);
      setRunning(false);
    }
  }, []);

  // ── Tick ──────────────────────────────────────────────────────
  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(() => {
        const extra = Math.floor((Date.now() - epochRef.current) / 1000);
        const { elapsed: base } = loadTimerState();
        setElapsed(base + extra);
      }, 1000);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [running]);

  // ── 30-min alerts ─────────────────────────────────────────────
  const lastAlertRef = useRef(0);
  useEffect(() => {
    if (elapsed > 0 && elapsed % 1800 === 0 && elapsed !== lastAlertRef.current) {
      lastAlertRef.current = elapsed;
      toast.info(`⏰ ${Math.floor(elapsed / 60)} min de estudo! Dê uma pausa rápida.`, { duration: 5000 });
    }
  }, [elapsed]);

  // ── Keyboard shortcuts ────────────────────────────────────────
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.code === "Space") { e.preventDefault(); handlePlayPause(); }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [running]);

  // ── Controls ──────────────────────────────────────────────────
  const handlePlayPause = useCallback(() => {
    if (!running) {
      if (elapsed === 0) { setShowBriefing(true); return; }
      const epoch = Date.now();
      epochRef.current = epoch;
      saveTimerState(elapsed, true, epoch);
      setRunning(true);
    } else {
      const extra = Math.floor((Date.now() - epochRef.current) / 1000);
      const newElapsed = elapsed + extra;
      setElapsed(newElapsed);
      saveTimerState(newElapsed, false, 0);
      setRunning(false);
    }
  }, [running, elapsed]);

  const handleBriefingConfirm = (subject: string) => {
    setSelectedSubject(subject);
    setShowBriefing(false);
    const epoch = Date.now();
    epochRef.current = epoch;
    saveTimerState(0, true, epoch);
    setElapsed(0);
    setRunning(true);
  };

  const handleStop = () => {
    if (running) {
      const extra = Math.floor((Date.now() - epochRef.current) / 1000);
      setElapsed(e => e + extra);
    }
    setRunning(false);
    saveTimerState(elapsed, false, 0);
    setShowSaveDialog(true);
  };

  const handleReset = () => {
    setRunning(false);
    setElapsed(0);
    clearTimerState();
    lastAlertRef.current = 0;
    toast.info("Timer resetado.");
  };

  const handleSave = async () => {
    if (!questionsAttempted || !questionsCorrect) {
      toast.error("Preencha todos os campos");
      return;
    }
    const attempted = parseInt(questionsAttempted);
    const correct   = parseInt(questionsCorrect);
    if (correct > attempted) { toast.error("Acertos > tentativas?"); return; }

    const id     = `prod-${Date.now()}`;
    const sessId = currentSession?.id ?? 0;
    const sRate  = (correct / attempted * 100).toFixed(2);

    addProductivityRecord({
      id,
      sessionId:          sessId,
      sessionName:        currentSession?.name ?? "",
      date:               new Date().toISOString(),
      questionsAttempted: attempted,
      questionsCorrect:   correct,
      successRate:        parseFloat(sRate),
      duration:           Math.round(elapsed / 60),
    });

    try {
      await addProductivity({
        id,
        sessionId:          sessId,
        sessionName:        currentSession?.name ?? "",
        questionsAttempted: attempted,
        questionsCorrect:   correct,
        successRate:        sRate,
        duration:           Math.round(elapsed / 60),
      });
    } catch { /* no-op if not authenticated */ }

    completeSession(sessId);
    setShowSaveDialog(false);
    setQuestionsAttempted("");
    setQuestionsCorrect("");
    setElapsed(0);
    clearTimerState();
    lastAlertRef.current = 0;
    toast.success("✅ Sessão salva com sucesso!");
  };

  const progressPct = (cycleProgress.completedSessions.length / cycleProgress.totalSessions) * 100;
  const quality     = qualityInfo(elapsed);
  const totalDur    = currentSession?.duration ?? TIMER_DURATION;

  return (
    <Layout>
      <div className="container mx-auto py-8 px-4 max-w-5xl fade-in">
        {/* Header */}
        <div className="mb-8">
          <h1
            style={{
              fontSize: "2rem",
              fontWeight: 800,
              letterSpacing: "-0.03em",
              background: "linear-gradient(135deg, #fff 0%, rgba(255,107,53,0.9) 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              marginBottom: "0.25rem",
            }}
          >
            Ciclo Contínuo de Estudos
          </h1>
          <p style={{ color: "var(--muted-foreground)", fontSize: "0.9rem" }}>
            Sessões de 2h cada · Progresso: {cycleProgress.completedSessions.length}/{cycleProgress.totalSessions} ·{" "}
            <kbd style={{ fontSize: "0.7rem", background: "rgba(200,80,120,0.2)", border: "1px solid rgba(200,80,120,0.3)", padding: "1px 5px", borderRadius: "4px" }}>
              Espaço
            </kbd>{" "}
            Play/Pause
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Timer card */}
          <div className="lg:col-span-2">
            <div className={`glass-card p-8 ${running ? "timer-container-active" : ""}`}>
              <div className="text-center mb-8">
                <h2 style={{ fontSize: "1.25rem", fontWeight: 700, color: "var(--coral)", marginBottom: "4px" }}>
                  {currentSession?.name} — {selectedSubject || currentSession?.subject}
                </h2>
                <p style={{ color: "var(--muted-foreground)", fontSize: "0.85rem" }}>Sessão atual</p>
              </div>

              {/* Clock display */}
              <div
                className="rounded-2xl p-10 text-center mb-8"
                style={{
                  background: "rgba(26,10,46,0.6)",
                  border: "1px solid rgba(200,80,120,0.2)",
                }}
              >
                <div
                  className={`font-mono font-black mb-2 ${running ? "timer-pulse" : ""}`}
                  style={{
                    fontSize: "clamp(3rem, 10vw, 5rem)",
                    color: running ? "var(--coral)" : "var(--foreground)",
                    letterSpacing: "-0.02em",
                    transition: "color 0.3s",
                  }}
                >
                  {formatTime(elapsed)}
                </div>

                {/* Quality badge */}
                {elapsed > 0 && (
                  <div
                    className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium mb-4 ${quality.cls}`}
                    style={{ border: "1px solid" }}
                  >
                    {quality.emoji} {quality.label}
                  </div>
                )}

                {/* Progress bar for current session */}
                <div
                  className="w-full rounded-full overflow-hidden"
                  style={{ height: "4px", background: "rgba(200,80,120,0.2)", marginBottom: "24px" }}
                >
                  <div
                    style={{
                      height: "100%",
                      width: `${Math.min((elapsed / totalDur) * 100, 100)}%`,
                      background: "linear-gradient(90deg, var(--coral), var(--amber))",
                      transition: "width 1s linear",
                      borderRadius: "9999px",
                    }}
                  />
                </div>

                {/* Buttons */}
                <div className="flex gap-3 justify-center flex-wrap">
                  <button
                    onClick={handlePlayPause}
                    className="btn-coral flex items-center gap-2 px-6 py-3 rounded-xl font-semibold"
                    style={{ fontSize: "0.95rem" }}
                  >
                    {running ? <><Pause size={18} /> Pausar</> : <><Play size={18} /> {elapsed === 0 ? "Iniciar" : "Continuar"}</>}
                  </button>

                  {(running || elapsed > 0) && (
                    <button
                      onClick={handleStop}
                      className="btn-glass flex items-center gap-2 px-6 py-3 rounded-xl font-semibold"
                      style={{
                        background: "rgba(231,76,60,0.15)",
                        borderColor: "rgba(231,76,60,0.35)",
                        color: "#e74c3c",
                      }}
                    >
                      <Square size={18} /> Parar e Salvar
                    </button>
                  )}

                  <button
                    onClick={handleReset}
                    className="btn-glass flex items-center gap-2 px-4 py-3 rounded-xl"
                  >
                    <RotateCcw size={16} />
                    <span className="hidden sm:inline">Resetar</span>
                  </button>
                </div>
              </div>

              {/* Session info */}
              <div className="grid grid-cols-2 gap-4">
                {[
                  { label: "Duração Alvo", value: `${(totalDur / 60).toFixed(0)} min`, icon: <Clock size={14} /> },
                  { label: "Matéria",      value: selectedSubject || currentSession?.subject || "—", icon: <Zap size={14} /> },
                ].map(({ label, value, icon }) => (
                  <div
                    key={label}
                    className="rounded-xl p-4"
                    style={{ background: "rgba(26,10,46,0.5)", border: "1px solid rgba(200,80,120,0.15)" }}
                  >
                    <p style={{ fontSize: "0.75rem", color: "var(--muted-foreground)", marginBottom: "4px" }}>{label}</p>
                    <p style={{ fontWeight: 600, display: "flex", alignItems: "center", gap: "6px", color: "var(--coral)" }}>
                      {icon} {value}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Cycle progress */}
          <div>
            <div className="glass-card p-6">
              <h3 style={{ fontWeight: 700, marginBottom: "20px", fontSize: "1rem" }}>
                Progresso do Ciclo
              </h3>

              <div className="mb-6">
                <div
                  className="w-full rounded-full overflow-hidden mb-2"
                  style={{ height: "6px", background: "rgba(200,80,120,0.2)" }}
                >
                  <div
                    style={{
                      height: "100%",
                      width: `${progressPct}%`,
                      background: "linear-gradient(90deg, var(--coral), var(--amber))",
                      transition: "width 0.5s ease",
                      borderRadius: "9999px",
                    }}
                  />
                </div>
                <p style={{ fontSize: "0.8rem", color: "var(--muted-foreground)", textAlign: "center" }}>
                  {Math.round(progressPct)}% completo
                </p>
              </div>

              <div className="space-y-2">
                {STUDY_SESSIONS.map((session) => {
                  const done    = cycleProgress.completedSessions.includes(session.id);
                  const current = session.id === currentSession?.id;
                  return (
                    <div
                      key={session.id}
                      className="px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200"
                      style={{
                        background: done
                          ? "rgba(39,174,96,0.12)"
                          : current
                          ? "rgba(255,107,53,0.12)"
                          : "rgba(26,10,46,0.5)",
                        border: `1px solid ${done ? "rgba(39,174,96,0.3)" : current ? "rgba(255,107,53,0.3)" : "rgba(200,80,120,0.1)"}`,
                        color: done ? "#27ae60" : current ? "var(--coral)" : "var(--muted-foreground)",
                      }}
                    >
                      <div className="flex items-center gap-2">
                        {done && <CheckCircle2 size={14} />}
                        {current && <Clock size={14} />}
                        <span style={{ fontSize: "0.8rem" }}>
                          {session.name}: {session.subject}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Session Briefing */}
      <SessionBriefing
        open={showBriefing}
        onConfirm={handleBriefingConfirm}
        onCancel={() => setShowBriefing(false)}
      />

      {/* Save Dialog */}
      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent style={{ background: "#1e0835", border: "1px solid rgba(200,80,120,0.3)" }}>
          <DialogHeader>
            <DialogTitle style={{ color: "var(--coral)" }}>Registrar Sessão</DialogTitle>
          </DialogHeader>

          {/* Quality display */}
          <div
            className={`rounded-xl p-4 mb-2 ${quality.cls}`}
            style={{ border: "1px solid" }}
          >
            <p style={{ fontSize: "0.8rem", marginBottom: "2px" }}>Tempo estudado</p>
            <p style={{ fontSize: "1.5rem", fontWeight: 800, fontFamily: "monospace" }}>
              {formatTime(elapsed)}
            </p>
            <p style={{ fontSize: "0.8rem", marginTop: "4px" }}>{quality.label}</p>
          </div>

          <div className="space-y-4">
            <div>
              <Label style={{ color: "var(--muted-foreground)", fontSize: "0.8rem" }}>
                Questões realizadas
              </Label>
              <Input
                type="number" min="0"
                value={questionsAttempted}
                onChange={(e) => setQuestionsAttempted(e.target.value)}
                placeholder="Ex: 20"
                className="mt-1"
              />
            </div>
            <div>
              <Label style={{ color: "var(--muted-foreground)", fontSize: "0.8rem" }}>
                Acertos
              </Label>
              <Input
                type="number" min="0"
                value={questionsCorrect}
                onChange={(e) => setQuestionsCorrect(e.target.value)}
                placeholder="Ex: 16"
                className="mt-1"
              />
            </div>
            {questionsAttempted && questionsCorrect && parseInt(questionsAttempted) > 0 && (
              <div
                className="rounded-lg p-3"
                style={{ background: "rgba(255,107,53,0.1)", border: "1px solid rgba(255,107,53,0.25)" }}
              >
                <p style={{ fontSize: "0.75rem", color: "var(--muted-foreground)" }}>Taxa de acerto</p>
                <p style={{ fontSize: "1.75rem", fontWeight: 800, color: "var(--coral)" }}>
                  {Math.round((parseInt(questionsCorrect) / parseInt(questionsAttempted)) * 100)}%
                </p>
              </div>
            )}
          </div>

          <DialogFooter>
            <button
              className="btn-glass px-4 py-2 rounded-xl text-sm"
              onClick={() => setShowSaveDialog(false)}
            >
              Cancelar
            </button>
            <button
              className="btn-coral px-6 py-2 rounded-xl text-sm"
              onClick={handleSave}
            >
              Salvar e Avançar
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
