import React, { useMemo } from "react";
import Layout from "@/components/Layout";
import RadarDePegadinhas from "@/components/RadarDePegadinhas";
import MedalShowcase from "@/components/MedalShowcase";
import StudyCalendar from "@/components/StudyCalendar";
import WeakPointsFilter from "@/components/WeakPointsFilter";
import { Card } from "@/components/ui/card";
import { useStudyCycle } from "@/contexts/StudyCycleContext";
import { STUDY_SESSIONS, EditorialTopic } from "@/types";
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts";
import { Clock, TrendingUp, AlertCircle, CheckCircle2 } from "lucide-react";

export default function Dashboard() {
  const { productivityRecords, errorEntries, editorialTopics } = useStudyCycle();

  const calculateFreshness = (topic: EditorialTopic): "green" | "yellow" | "red" => {
    if (!topic.lastReviewDate) return "red";
    
    const lastReview = new Date(topic.lastReviewDate);
    const today = new Date();
    const daysSinceReview = Math.floor((today.getTime() - lastReview.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysSinceReview < 15) return "green";
    if (daysSinceReview < 30) return "yellow";
    return "red";
  };

  const criticalTopicsCount = useMemo(() => {
    return editorialTopics.filter((t) => calculateFreshness(t) === "red").length;
  }, [editorialTopics]);

  // Cálculos de métricas
  const metrics = useMemo(() => {
    const totalAccuracy = productivityRecords.length > 0
      ? productivityRecords.reduce((sum, r) => sum + r.successRate, 0) / productivityRecords.length
      : 0;

    const totalNetHours = productivityRecords.reduce((sum, r) => sum + r.duration, 0) / 60;

    const accuracyBySubject: Record<string, { total: number; count: number }> = {};
    productivityRecords.forEach((record) => {
      if (!accuracyBySubject[record.sessionName]) {
        accuracyBySubject[record.sessionName] = { total: 0, count: 0 };
      }
      accuracyBySubject[record.sessionName].total += record.successRate;
      accuracyBySubject[record.sessionName].count += 1;
    });

    const errorDistribution: Record<string, number> = {
      "Lei Seca": 0,
      "Atenção": 0,
      "Teoria": 0,
    };
    errorEntries.forEach((error) => {
      errorDistribution[error.errorType]++;
    });

    const legislationErrors = errorEntries.filter((e) => e.category === "Legislação").length;
    const generalErrors = errorEntries.filter((e) => e.category === "Geral").length;

    return {
      totalAccuracy: Math.round(totalAccuracy * 100) / 100,
      totalNetHours: Math.round(totalNetHours * 100) / 100,
      accuracyBySubject,
      errorDistribution,
      legislationErrors,
      generalErrors,
    };
  }, [productivityRecords, errorEntries]);

  // Dados para gráfico de barras (Acurácia por Matéria)
  const accuracyChartData = useMemo(() => {
    return Object.entries(metrics.accuracyBySubject).map(([subject, data]) => ({
      subject,
      accuracy: Math.round((data.total / data.count) * 100) / 100,
    }));
  }, [metrics.accuracyBySubject]);

  // Dados para gráfico de pizza (Distribuição de Erros)
  const errorChartData = useMemo(() => {
    return Object.entries(metrics.errorDistribution)
      .filter(([, count]) => count > 0)
      .map(([name, value]) => ({
        name,
        value,
      }));
  }, [metrics.errorDistribution]);

  // Dados para gráfico de linha (Progresso ao longo do tempo)
  const progressChartData = useMemo(() => {
    return productivityRecords
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .map((record, index) => ({
        session: `${record.sessionName}`,
        accuracy: record.successRate,
        index,
      }));
  }, [productivityRecords]);

  const colors = ["#3b82f6", "#10b981", "#f97316", "#7c3aed", "#06b6d4"];

  return (
    <Layout>
      <div className="container mx-auto py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Dashboard de Performance</h1>
          <p className="text-muted-foreground">
            Acompanhe seu progresso, medalhas e análise de desempenho
          </p>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
          <Card className="p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Taxa de Acerto Geral</p>
                <p className="text-3xl font-bold text-primary">{metrics.totalAccuracy}%</p>
              </div>
              <CheckCircle2 className="w-10 h-10 text-accent opacity-50" />
            </div>
          </Card>

          <Card className="p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Horas Líquidas</p>
                <p className="text-3xl font-bold text-primary">{metrics.totalNetHours}h</p>
              </div>
              <Clock className="w-10 h-10 text-blue-500 opacity-50" />
            </div>
          </Card>

          <Card className="p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Erros Legislação</p>
                <p className="text-3xl font-bold text-blue-500">{metrics.legislationErrors}</p>
              </div>
              <AlertCircle className="w-10 h-10 text-blue-500 opacity-50" />
            </div>
          </Card>

          <Card className="p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Erros Gerais</p>
                <p className="text-3xl font-bold text-purple-500">{metrics.generalErrors}</p>
              </div>
              <TrendingUp className="w-10 h-10 text-purple-500 opacity-50" />
            </div>
          </Card>

          <Card className="p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Temas Críticos</p>
                <p className={`text-3xl font-bold ${criticalTopicsCount > 0 ? "text-red-500" : "text-green-500"}`}>
                  {criticalTopicsCount}
                </p>
              </div>
              <AlertCircle className={`w-10 h-10 ${criticalTopicsCount > 0 ? "text-red-500" : "text-green-500"} opacity-50`} />
            </div>
          </Card>
        </div>

        {/* Seção de Gamificação */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <MedalShowcase />
          <StudyCalendar />
        </div>

        {/* Filtro de Ponto Fraco */}
        <div className="mb-6">
          <WeakPointsFilter />
        </div>

        {/* Radar de Pegadinhas */}
        <div className="mb-6">
          <RadarDePegadinhas />
        </div>

        {/* Gráficos */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Acurácia por Matéria */}
          <Card className="p-6 shadow-sm">
            <h3 className="text-lg font-semibold mb-4">Acurácia por Matéria</h3>
            {accuracyChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={accuracyChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.1} />
                  <XAxis dataKey="subject" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--card)",
                      border: "1px solid var(--border)",
                      borderRadius: "0.65rem",
                    }}
                    formatter={(value) => `${value}%`}
                  />
                  <Bar dataKey="accuracy" fill="#3b82f6" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-80 flex items-center justify-center text-muted-foreground">
                Nenhum dado disponível
              </div>
            )}
          </Card>

          {/* Distribuição de Erros */}
          <Card className="p-6 shadow-sm">
            <h3 className="text-lg font-semibold mb-4">Distribuição de Erros</h3>
            {errorChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={errorChartData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value}`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {errorChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--card)",
                      border: "1px solid var(--border)",
                      borderRadius: "0.65rem",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-80 flex items-center justify-center text-muted-foreground">
                Nenhum erro registrado
              </div>
            )}
          </Card>
        </div>

        {/* Progresso ao Longo do Tempo */}
        <Card className="p-6 shadow-sm">
          <h3 className="text-lg font-semibold mb-4">Progresso ao Longo do Tempo</h3>
          {progressChartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={progressChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="currentColor" opacity={0.1} />
                <XAxis dataKey="session" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--card)",
                    border: "1px solid var(--border)",
                    borderRadius: "0.65rem",
                  }}
                  formatter={(value) => `${value}%`}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="accuracy"
                  stroke="#3b82f6"
                  dot={{ fill: "#3b82f6", r: 4 }}
                  activeDot={{ r: 6 }}
                  name="Acurácia (%)"
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-80 flex items-center justify-center text-muted-foreground">
              Nenhum dado disponível
            </div>
          )}
        </Card>
      </div>
    </Layout>
  );
}
