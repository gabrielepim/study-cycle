import React, { useState, useMemo } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useStudyCycle } from "@/contexts/StudyCycleContext";
import { Trash2, Plus, BookOpen, Tag } from "lucide-react";
import { toast } from "sonner";

export default function Arguments() {
  const { arguments: savedArguments, addArgument, deleteArgument } = useStudyCycle();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState<"Relações Públicas" | "Legislação" | "Geral">("Relações Públicas");
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [tags, setTags] = useState("");
  const [filterSubject, setFilterSubject] = useState<"Relações Públicas" | "Legislação" | "Geral" | "Todos">("Todos");

  const filteredArguments = useMemo(() => {
    if (filterSubject === "Todos") {
      return savedArguments;
    }
    return savedArguments.filter((arg) => arg.subject === filterSubject);
  }, [savedArguments, filterSubject]);

  const handleAddArgument = () => {
    if (!title.trim() || !content.trim()) {
      toast.error("Preencha o título e o conteúdo");
      return;
    }

    addArgument({
      subject: selectedSubject,
      title: title.trim(),
      content: content.trim(),
      tags: tags
        .split(",")
        .map((tag) => tag.trim())
        .filter((tag) => tag.length > 0),
    });

    toast.success("Argumento adicionado com sucesso!");
    setTitle("");
    setContent("");
    setTags("");
    setIsDialogOpen(false);
  };

  const handleDeleteArgument = (id: string) => {
    deleteArgument(id);
    toast.success("Argumento removido");
  };

  const getSubjectColor = (subject: string) => {
    switch (subject) {
      case "Relações Públicas":
        return "bg-blue-500/10 border-blue-500/20 text-blue-600 dark:text-blue-400";
      case "Legislação":
        return "bg-red-500/10 border-red-500/20 text-red-600 dark:text-red-400";
      default:
        return "bg-purple-500/10 border-purple-500/20 text-purple-600 dark:text-purple-400";
    }
  };

  return (
    <Layout>
      <div className="container mx-auto py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Repositório de Argumentos</h1>
          <p className="text-muted-foreground">
            Salve citações, conceitos-chave e argumentos para usar em suas redações e estudos
          </p>
        </div>

        {/* Filtro e Botão */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="flex-1">
            <Select value={filterSubject} onValueChange={(value: any) => setFilterSubject(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Todos">Todos os Assuntos</SelectItem>
                <SelectItem value="Relações Públicas">Relações Públicas</SelectItem>
                <SelectItem value="Legislação">Legislação</SelectItem>
                <SelectItem value="Geral">Geral</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={() => setIsDialogOpen(true)} className="gap-2">
            <Plus className="w-4 h-4" />
            Novo Argumento
          </Button>
        </div>

        {/* Lista de Argumentos */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredArguments.length > 0 ? (
            filteredArguments.map((arg) => (
              <Card key={arg.id} className="p-4 shadow-sm hover:shadow-md transition-shadow duration-200 flex flex-col">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="font-semibold text-sm line-clamp-2">{arg.title}</h3>
                    <span className={`inline-block text-xs px-2 py-1 rounded mt-2 border ${getSubjectColor(arg.subject)}`}>
                      {arg.subject}
                    </span>
                  </div>
                  <button
                    onClick={() => handleDeleteArgument(arg.id)}
                    className="p-2 hover:bg-muted rounded transition-colors"
                    title="Deletar"
                  >
                    <Trash2 className="w-4 h-4 text-muted-foreground hover:text-destructive" />
                  </button>
                </div>

                <p className="text-sm text-muted-foreground line-clamp-4 mb-3 flex-1">{arg.content}</p>

                {arg.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-3">
                    {arg.tags.map((tag, index) => (
                      <span key={index} className="text-xs bg-muted px-2 py-1 rounded flex items-center gap-1">
                        <Tag className="w-3 h-3" />
                        {tag}
                      </span>
                    ))}
                  </div>
                )}

                <p className="text-xs text-muted-foreground">
                  {new Date(arg.createdDate).toLocaleDateString("pt-BR")}
                </p>
              </Card>
            ))
          ) : (
            <div className="col-span-full">
              <Card className="p-12 text-center">
                <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <p className="text-muted-foreground mb-4">Nenhum argumento salvo ainda</p>
                <Button onClick={() => setIsDialogOpen(true)} variant="outline" className="gap-2">
                  <Plus className="w-4 h-4" />
                  Criar Primeiro Argumento
                </Button>
              </Card>
            </div>
          )}
        </div>

        {/* Dialog para Novo Argumento */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-2xl">
            <DialogHeader>
              <DialogTitle>Novo Argumento</DialogTitle>
            </DialogHeader>

            <div className="space-y-4">
              {/* Assunto */}
              <div>
                <label className="text-sm font-medium mb-2 block">Assunto</label>
                <Select value={selectedSubject} onValueChange={(value: any) => setSelectedSubject(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Relações Públicas">Relações Públicas</SelectItem>
                    <SelectItem value="Legislação">Legislação</SelectItem>
                    <SelectItem value="Geral">Geral</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Título */}
              <div>
                <label className="text-sm font-medium mb-2 block">Título</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Ex: Comunicação Estratégica"
                  className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              {/* Conteúdo */}
              <div>
                <label className="text-sm font-medium mb-2 block">Conteúdo</label>
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Cole a citação, conceito ou argumento aqui..."
                  rows={6}
                  className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                />
              </div>

              {/* Tags */}
              <div>
                <label className="text-sm font-medium mb-2 block">Tags (separadas por vírgula)</label>
                <input
                  type="text"
                  value={tags}
                  onChange={(e) => setTags(e.target.value)}
                  placeholder="Ex: comunicação, estratégia, público"
                  className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleAddArgument} className="gap-2">
                <Plus className="w-4 h-4" />
                Adicionar Argumento
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}
