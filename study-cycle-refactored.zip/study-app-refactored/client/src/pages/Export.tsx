import React from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useStudyCycle } from "@/contexts/StudyCycleContext";
import { useExportCSV } from "@/hooks/useExportCSV";
import { useBackup } from "@/hooks/useBackup";
import { Download, FileText, AlertCircle, CheckCircle2, Database } from "lucide-react";
import { toast } from "sonner";

export default function Export() {
  const { productivityRecords, errorEntries, editorialTopics } = useStudyCycle();
  const {
    exportProductivityToCSV,
    exportErrorsToCSV,
    exportEditorialToCSV,
    exportCompleteHistoryToCSV,
  } = useExportCSV();
  const { exportAsJSON, exportAsCSV, exportAsText } = useBackup();

  const handleExportProductivity = () => {
    if (productivityRecords.length === 0) {
      toast.error("Nenhum registro de produtividade para exportar");
      return;
    }
    exportProductivityToCSV(productivityRecords, `produtividade_${new Date().toISOString().split("T")[0]}.csv`);
    toast.success("Produtividade exportada com sucesso!");
  };

  const handleExportErrors = () => {
    if (errorEntries.length === 0) {
      toast.error("Nenhum erro para exportar");
      return;
    }
    exportErrorsToCSV(errorEntries, `erros_${new Date().toISOString().split("T")[0]}.csv`);
    toast.success("Erros exportados com sucesso!");
  };

  const handleExportEditorial = () => {
    if (editorialTopics.length === 0) {
      toast.error("Nenhum tópico para exportar");
      return;
    }
    exportEditorialToCSV(editorialTopics, `edital_${new Date().toISOString().split("T")[0]}.csv`);
    toast.success("Edital exportado com sucesso!");
  };

  const handleExportComplete = () => {
    if (productivityRecords.length === 0 && errorEntries.length === 0 && editorialTopics.length === 0) {
      toast.error("Nenhum dado para exportar");
      return;
    }
    exportCompleteHistoryToCSV(
      productivityRecords,
      errorEntries,
      editorialTopics,
      `historico_completo_${new Date().toISOString().split("T")[0]}.csv`
    );
    toast.success("Histórico completo exportado com sucesso!");
  };

  const handleBackupJSON = () => {
    exportAsJSON();
    toast.success("Backup em JSON exportado com sucesso!");
  };

  const handleBackupCSV = () => {
    exportAsCSV();
    toast.success("Backup em CSV exportado com sucesso!");
  };

  const handleBackupText = () => {
    exportAsText();
    toast.success("Relatório em TXT exportado com sucesso!");
  };

  return (
    <Layout>
      <div className="container mx-auto py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Exportar Dados</h1>
          <p className="text-muted-foreground">
            Exporte seu histórico de estudos em múltiplos formatos para análise externa e backup
          </p>
        </div>

        {/* Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Registros de Produtividade</p>
                <p className="text-3xl font-bold text-primary">{productivityRecords.length}</p>
              </div>
              <CheckCircle2 className="w-10 h-10 text-green-500 opacity-50" />
            </div>
          </Card>

          <Card className="p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Erros Registrados</p>
                <p className="text-3xl font-bold text-primary">{errorEntries.length}</p>
              </div>
              <AlertCircle className="w-10 h-10 text-red-500 opacity-50" />
            </div>
          </Card>

          <Card className="p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Tópicos do Edital</p>
                <p className="text-3xl font-bold text-primary">{editorialTopics.length}</p>
              </div>
              <FileText className="w-10 h-10 text-blue-500 opacity-50" />
            </div>
          </Card>
        </div>

        {/* Sistema de Backup */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <Database className="w-6 h-6" />
            Sistema de Backup Completo
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="p-4 shadow-sm hover:shadow-md transition-shadow">
              <h4 className="font-semibold mb-2">Backup JSON</h4>
              <p className="text-xs text-muted-foreground mb-4">
                Exporta todos os dados em formato JSON estruturado. Ideal para backup e restauração completa.
              </p>
              <Button onClick={handleBackupJSON} size="sm" className="w-full gap-2">
                <Download className="w-4 h-4" />
                Exportar JSON
              </Button>
            </Card>

            <Card className="p-4 shadow-sm hover:shadow-md transition-shadow">
              <h4 className="font-semibold mb-2">Backup CSV</h4>
              <p className="text-xs text-muted-foreground mb-4">
                Exporta produtividade e erros em CSV. Compatível com Excel e Google Sheets.
              </p>
              <Button onClick={handleBackupCSV} size="sm" className="w-full gap-2">
                <Download className="w-4 h-4" />
                Exportar CSV
              </Button>
            </Card>

            <Card className="p-4 shadow-sm hover:shadow-md transition-shadow">
              <h4 className="font-semibold mb-2">Relatório TXT</h4>
              <p className="text-xs text-muted-foreground mb-4">
                Gera um relatório legível em texto com resumo completo do progresso.
              </p>
              <Button onClick={handleBackupText} size="sm" className="w-full gap-2">
                <Download className="w-4 h-4" />
                Exportar TXT
              </Button>
            </Card>
          </div>
        </div>

        {/* Opções de Exportação */}
        <div className="space-y-6">
          {/* Exportar Produtividade */}
          <Card className="p-6 shadow-sm">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold mb-2">Histórico de Produtividade</h3>
                <p className="text-sm text-muted-foreground">
                  Exporte todos os seus registros de sessões de estudo, incluindo questões feitas, acertos e taxa de acerto.
                </p>
              </div>
            </div>
            <Button
              onClick={handleExportProductivity}
              disabled={productivityRecords.length === 0}
              className="gap-2"
            >
              <Download className="w-4 h-4" />
              Exportar Produtividade
            </Button>
          </Card>

          {/* Exportar Erros */}
          <Card className="p-6 shadow-sm">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold mb-2">Caderno de Erros</h3>
                <p className="text-sm text-muted-foreground">
                  Exporte todos os seus erros registrados com categorização, tipo de erro e descrição detalhada.
                </p>
              </div>
            </div>
            <Button
              onClick={handleExportErrors}
              disabled={errorEntries.length === 0}
              className="gap-2"
            >
              <Download className="w-4 h-4" />
              Exportar Erros
            </Button>
          </Card>

          {/* Exportar Edital */}
          <Card className="p-6 shadow-sm">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold mb-2">Edital Verticalizado</h3>
                <p className="text-sm text-muted-foreground">
                  Exporte seu edital verticalizado com status de conclusão de cada tópico e subtópico.
                </p>
              </div>
            </div>
            <Button
              onClick={handleExportEditorial}
              disabled={editorialTopics.length === 0}
              className="gap-2"
            >
              <Download className="w-4 h-4" />
              Exportar Edital
            </Button>
          </Card>

          {/* Exportar Tudo */}
          <Card className="p-6 shadow-sm border-2 border-primary/50 bg-primary/5">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold mb-2">Histórico Completo</h3>
                <p className="text-sm text-muted-foreground">
                  Exporte um arquivo consolidado com produtividade, erros e edital em um único CSV.
                </p>
              </div>
            </div>
            <Button
              onClick={handleExportComplete}
              disabled={
                productivityRecords.length === 0 &&
                errorEntries.length === 0 &&
                editorialTopics.length === 0
              }
              className="gap-2"
            >
              <Download className="w-4 h-4" />
              Exportar Histórico Completo
            </Button>
          </Card>
        </div>

        {/* Informações */}
        <Card className="p-6 shadow-sm mt-8 bg-blue-500/10 border border-blue-500/20">
          <h4 className="font-semibold mb-2 text-blue-600 dark:text-blue-400">Informações sobre Exportação</h4>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>• Os arquivos são exportados em múltiplos formatos: JSON, CSV e TXT</li>
            <li>• JSON: Ideal para backup completo com estrutura preservada</li>
            <li>• CSV: Compatível com Excel, Google Sheets e ferramentas de análise</li>
            <li>• TXT: Relatório legível com resumo do progresso</li>
            <li>• Todos os dados são salvos localmente no seu navegador e nunca são enviados para servidores</li>
            <li>• Os arquivos incluem um timestamp para fácil identificação</li>
          </ul>
        </Card>
      </div>
    </Layout>
  );
}
