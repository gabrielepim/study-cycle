import React, { useState, useMemo, useEffect } from "react";
import Layout from "@/components/Layout";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ExamQuestion, STUDY_SESSIONS } from "@/types";
import { Plus, Trash2, Eye, EyeOff, CheckCircle, XCircle } from "lucide-react";
import { toast } from "sonner";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { trpc } from "@/lib/trpc";

const STORAGE_KEY = "study-cycle:exam-questions";
type QType = "Múltipla Escolha" | "Verdadeiro/Falso" | "Discursiva";

export default function ExamQuestions() {
  const [questions, setQuestions] = useLocalStorage<ExamQuestion[]>(STORAGE_KEY, []);
  const addQMut    = trpc.examQuestions.add.useMutation();
  const deleteQMut = trpc.examQuestions.delete.useMutation();

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [revealedAnswers, setRevealedAnswers] = useState<Set<string>>(new Set());
  const [filterSubject, setFilterSubject] = useState("Todos");
  const [filterType,    setFilterType]    = useState("Todos");

  const emptyForm = (): Partial<ExamQuestion> => ({
    organ:"", banca:"", year: new Date().getFullYear(),
    subject: STUDY_SESSIONS[0].subject,
    enunciation: "",
    alternatives: { a:"", b:"", c:"", d:"", e:"" },
    correctAnswer: "a",
    questionType: "Múltipla Escolha",
    errorTags: [], comments:"", isRevealed: false,
    discursiveMirror: "",
  });

  const [formData, setFormData] = useState<any>(emptyForm());

  // Ctrl+Enter to save
  useEffect(() => {
    if (!isDialogOpen) return;
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter") handleAdd();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [isDialogOpen, formData]);

  const showAlts = formData.questionType !== "Discursiva";
  const showCDE  = formData.questionType === "Múltipla Escolha";

  const filtered = useMemo(() => questions.filter(q => {
    const sOk = filterSubject === "Todos" || q.subject === filterSubject;
    const tOk = filterType    === "Todos" || q.questionType === filterType;
    return sOk && tOk;
  }), [questions, filterSubject, filterType]);

  const handleAdd = async () => {
    if (!formData.enunciation?.trim()) { toast.error("Preencha o enunciado"); return; }
    const id = `q-${Date.now()}`;
    const newQ: ExamQuestion = {
      id,
      organ:        formData.organ || "",
      banca:        formData.banca || "",
      year:         formData.year,
      subject:      formData.subject || STUDY_SESSIONS[0].subject,
      enunciation:  formData.enunciation,
      alternatives: formData.alternatives,
      correctAnswer: formData.correctAnswer as any,
      userAnswer:   undefined,
      questionType: formData.questionType as any,
      errorTags:    formData.errorTags || [],
      comments:     formData.comments || "",
      date:         new Date().toISOString(),
      isRevealed:   false,
    };
    setQuestions(prev => [...prev, newQ]);
    try {
      await addQMut.mutateAsync({
        id, organ: newQ.organ, banca: newQ.banca, year: newQ.year,
        subject: newQ.subject, enunciation: newQ.enunciation,
        alternatives: newQ.alternatives, correctAnswer: newQ.correctAnswer as any,
        questionType: newQ.questionType as any, errorTags: [], comments: newQ.comments,
      });
    } catch {}
    toast.success("Questão adicionada!");
    setIsDialogOpen(false);
    setFormData(emptyForm());
  };

  const handleDelete = async (id: string) => {
    setQuestions(prev => prev.filter(q => q.id !== id));
    try { await deleteQMut.mutateAsync({ id }); } catch {}
    toast.success("Removida");
  };

  const toggleReveal = (id: string) => {
    setRevealedAnswers(prev => {
      const s = new Set(prev);
      s.has(id) ? s.delete(id) : s.add(id);
      return s;
    });
  };

  const altLabel = (k: string) => k.toUpperCase();

  const typeLabel: Record<QType, string> = {
    "Múltipla Escolha": "MC",
    "Verdadeiro/Falso": "V/F",
    "Discursiva": "Disc",
  };

  return (
    <Layout>
      <div className="container mx-auto py-8 px-4 max-w-5xl fade-in">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 style={{ fontSize: "2rem", fontWeight: 800, letterSpacing: "-0.03em",
              background: "linear-gradient(135deg, #fff, rgba(255,107,53,0.9))",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            }}>
              Questões Concurso
            </h1>
            <p style={{ color: "var(--muted-foreground)", fontSize: "0.875rem" }}>
              Active Recall — resposta oculta por padrão
            </p>
          </div>
          <button onClick={() => setIsDialogOpen(true)} className="btn-coral flex items-center gap-2 px-5 py-2.5 rounded-xl self-start">
            <Plus size={16} /> Nova Questão
          </button>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <Select value={filterSubject} onValueChange={setFilterSubject}>
            <SelectTrigger className="rounded-xl flex-1"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="Todos">Todas as Matérias</SelectItem>
              {STUDY_SESSIONS.map(s => <SelectItem key={s.id} value={s.subject}>{s.subject}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="rounded-xl flex-1"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="Todos">Todos os Tipos</SelectItem>
              {(["Múltipla Escolha","Verdadeiro/Falso","Discursiva"] as QType[]).map(t => (
                <SelectItem key={t} value={t}>{t}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Questions */}
        <div className="space-y-4">
          {filtered.length === 0 && (
            <div className="glass-card p-12 text-center">
              <p style={{ color: "var(--muted-foreground)" }}>Nenhuma questão cadastrada.</p>
            </div>
          )}
          {filtered.map(q => {
            const revealed = revealedAnswers.has(q.id);
            return (
              <div key={q.id} className="glass-card p-6 fade-in">
                <div className="flex flex-wrap items-center gap-2 mb-4 pb-3" style={{ borderBottom: "1px solid rgba(200,80,120,0.15)" }}>
                  {q.organ && <span style={{ fontSize: "0.75rem", color: "var(--muted-foreground)" }}>{q.organ}</span>}
                  {q.banca && <span style={{ fontSize: "0.75rem", color: "var(--muted-foreground)" }}>{q.banca}</span>}
                  {q.year  && <span style={{ fontSize: "0.75rem", color: "var(--muted-foreground)" }}>{q.year}</span>}
                  <span style={{ fontSize: "0.8rem", color: "var(--coral)", fontWeight: 600 }}>{q.subject}</span>
                  <span className="px-2 py-0.5 rounded-full text-xs"
                    style={{ background: "rgba(255,107,53,0.1)", color: "var(--coral)", border: "1px solid rgba(255,107,53,0.25)" }}>
                    {q.questionType}
                  </span>
                  <div className="ml-auto flex gap-1">
                    <button onClick={() => toggleReveal(q.id)} className="p-1.5 rounded-lg transition-all"
                      style={{ background: revealed ? "rgba(39,174,96,0.15)" : "rgba(200,80,120,0.15)", color: revealed ? "#27ae60" : "var(--muted-foreground)" }}>
                      {revealed ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                    <button onClick={() => handleDelete(q.id)} className="p-1.5 rounded-lg"
                      style={{ background: "rgba(231,76,60,0.1)", color: "var(--muted-foreground)" }}
                      onMouseEnter={(e) => (e.currentTarget as HTMLElement).style.color = "#e74c3c"}
                      onMouseLeave={(e) => (e.currentTarget as HTMLElement).style.color = "var(--muted-foreground)"}>
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                <p style={{ fontSize: "0.9rem", lineHeight: 1.6, marginBottom: "12px" }}>{q.enunciation}</p>

                {q.questionType !== "Discursiva" && (
                  <div className="space-y-1.5 mb-4">
                    {(["a","b","c","d","e"] as const)
                      .filter(k => q.questionType === "Múltipla Escolha" || ["a","b"].includes(k))
                      .map(k => {
                        const isCorrect = revealed && q.correctAnswer === k;
                        return (
                          <div key={k} className="flex items-center gap-2 px-3 py-2 rounded-lg transition-all"
                            style={{
                              background: isCorrect ? "rgba(39,174,96,0.15)" : "rgba(26,10,46,0.4)",
                              border: `1px solid ${isCorrect ? "rgba(39,174,96,0.3)" : "rgba(200,80,120,0.1)"}`,
                            }}>
                            <span style={{ fontWeight: 700, fontSize: "0.8rem", color: isCorrect ? "#27ae60" : "var(--coral)", width: "20px" }}>
                              {k.toUpperCase()})
                            </span>
                            <span style={{ fontSize: "0.85rem", color: isCorrect ? "#27ae60" : "var(--foreground)" }}>
                              {(q.alternatives as any)[k] || "—"}
                            </span>
                            {isCorrect && <CheckCircle size={14} style={{ color: "#27ae60", marginLeft: "auto" }} />}
                          </div>
                        );
                    })}
                  </div>
                )}

                {/* Reveal answer */}
                {!revealed ? (
                  <button onClick={() => toggleReveal(q.id)}
                    className="btn-glass flex items-center gap-2 px-4 py-2 rounded-xl text-sm w-full justify-center"
                    style={{ marginTop: "8px" }}>
                    <Eye size={14} /> Ver Resposta
                  </button>
                ) : (
                  <div className="mt-3 px-4 py-3 rounded-xl"
                    style={{ background: "rgba(39,174,96,0.1)", border: "1px solid rgba(39,174,96,0.3)" }}>
                    <div className="flex items-center gap-2">
                      <CheckCircle size={14} style={{ color: "#27ae60" }} />
                      <span style={{ fontSize: "0.8rem", color: "#27ae60", fontWeight: 600 }}>
                        Resposta Correta: {q.correctAnswer.toUpperCase()}
                      </span>
                    </div>
                    {q.comments && (
                      <p style={{ fontSize: "0.8rem", color: "var(--muted-foreground)", marginTop: "8px" }}>
                        {q.comments}
                      </p>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent style={{ background: "#1e0835", border: "1px solid rgba(200,80,120,0.3)", maxWidth: "600px", maxHeight: "85vh", overflowY: "auto" }}>
          <DialogHeader>
            <DialogTitle style={{ color: "var(--coral)" }}>Nova Questão</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Órgão</Label>
                <Input value={formData.organ} onChange={e => setFormData((f:any) => ({...f, organ: e.target.value}))} placeholder="Ex: CESPE" className="mt-1 rounded-xl" />
              </div>
              <div>
                <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Banca</Label>
                <Input value={formData.banca} onChange={e => setFormData((f:any) => ({...f, banca: e.target.value}))} placeholder="Ex: Câmara" className="mt-1 rounded-xl" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Ano</Label>
                <Input type="number" value={formData.year} onChange={e => setFormData((f:any) => ({...f, year: parseInt(e.target.value)}))} className="mt-1 rounded-xl" />
              </div>
              <div>
                <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Matéria *</Label>
                <Select value={formData.subject} onValueChange={v => setFormData((f:any) => ({...f, subject: v}))}>
                  <SelectTrigger className="mt-1 rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {STUDY_SESSIONS.map(s => <SelectItem key={s.id} value={s.subject}>{s.subject}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Tipo *</Label>
              <Select value={formData.questionType} onValueChange={v => setFormData((f:any) => ({...f, questionType: v}))}>
                <SelectTrigger className="mt-1 rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {(["Múltipla Escolha","Verdadeiro/Falso","Discursiva"] as QType[]).map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Enunciado *</Label>
              <textarea
                value={formData.enunciation}
                onChange={e => setFormData((f:any) => ({...f, enunciation: e.target.value}))}
                rows={3} placeholder="Enunciado da questão..."
                style={{ width:"100%", marginTop:"4px", resize:"vertical", background:"rgba(90,20,60,0.4)", border:"1px solid rgba(200,80,120,0.25)", borderRadius:"0.75rem", padding:"10px 12px", color:"var(--foreground)", fontSize:"0.875rem", fontFamily:"inherit" }}
              />
            </div>

            {/* Alternatives (hidden for Discursiva) */}
            {showAlts && (
              <div>
                <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Alternativas</Label>
                <div className="space-y-2 mt-1">
                  {(["a","b"] as const).map(k => (
                    <div key={k} className="flex items-center gap-2">
                      <span style={{ width:"20px", fontWeight:700, color:"var(--coral)", flexShrink:0 }}>{k.toUpperCase()})</span>
                      <Input value={formData.alternatives[k]} onChange={e => setFormData((f:any) => ({...f, alternatives:{...f.alternatives,[k]:e.target.value}}))} placeholder={`Alternativa ${k.toUpperCase()}`} className="rounded-xl" />
                    </div>
                  ))}
                  {showCDE && (["c","d","e"] as const).map(k => (
                    <div key={k} className="flex items-center gap-2">
                      <span style={{ width:"20px", fontWeight:700, color:"var(--coral)", flexShrink:0 }}>{k.toUpperCase()})</span>
                      <Input value={formData.alternatives[k]} onChange={e => setFormData((f:any) => ({...f, alternatives:{...f.alternatives,[k]:e.target.value}}))} placeholder={`Alternativa ${k.toUpperCase()}`} className="rounded-xl" />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Discursiva mirror */}
            {formData.questionType === "Discursiva" && (
              <div>
                <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Espelho de Resposta</Label>
                <textarea
                  value={formData.discursivaMirror}
                  onChange={e => setFormData((f:any) => ({...f, discursivaMirror: e.target.value}))}
                  rows={3} placeholder="Resposta esperada / gabarito..."
                  style={{ width:"100%", marginTop:"4px", resize:"vertical", background:"rgba(90,20,60,0.4)", border:"1px solid rgba(200,80,120,0.25)", borderRadius:"0.75rem", padding:"10px 12px", color:"var(--foreground)", fontSize:"0.875rem", fontFamily:"inherit" }}
                />
              </div>
            )}

            {/* Correct answer (not for Discursiva) */}
            {showAlts && (
              <div>
                <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Gabarito</Label>
                <Select value={formData.correctAnswer} onValueChange={v => setFormData((f:any) => ({...f, correctAnswer: v}))}>
                  <SelectTrigger className="mt-1 rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {(showCDE ? ["a","b","c","d","e"] : ["a","b"]).map(k => <SelectItem key={k} value={k}>{k.toUpperCase()}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div>
              <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Comentário / Justificativa</Label>
              <textarea
                value={formData.comments}
                onChange={e => setFormData((f:any) => ({...f, comments: e.target.value}))}
                rows={2} placeholder="Por que esta é a resposta correta?"
                style={{ width:"100%", marginTop:"4px", resize:"vertical", background:"rgba(90,20,60,0.4)", border:"1px solid rgba(200,80,120,0.25)", borderRadius:"0.75rem", padding:"10px 12px", color:"var(--foreground)", fontSize:"0.875rem", fontFamily:"inherit" }}
              />
            </div>

            <p style={{ fontSize: "0.7rem", color: "var(--muted-foreground)" }}>💡 Ctrl+Enter para salvar</p>
          </div>

          <DialogFooter>
            <button className="btn-glass px-4 py-2 rounded-xl text-sm" onClick={() => setIsDialogOpen(false)}>Cancelar</button>
            <button className="btn-coral px-6 py-2 rounded-xl text-sm" onClick={handleAdd}>Adicionar Questão</button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
