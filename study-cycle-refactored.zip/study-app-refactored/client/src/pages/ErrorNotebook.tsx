import React, { useState, useMemo, useEffect } from "react";
import Layout from "@/components/Layout";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useStudyCycle } from "@/contexts/StudyCycleContext";
import { STUDY_SESSIONS } from "@/types";
import { Plus, Trash2, Filter, AlertCircle, BookOpen, Target } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

type QType = "Múltipla Escolha" | "Verdadeiro/Falso" | "Discursiva";
type EType = "Lei Seca" | "Atenção" | "Teoria";

export default function ErrorNotebook() {
  const { errorEntries, addErrorEntry, deleteErrorEntry } = useStudyCycle();
  const deleteEntryMut = trpc.errors.deleteEntry.useMutation();
  const addEntryMut    = trpc.errors.addEntry.useMutation();

  const [showDialog, setShowDialog]       = useState(false);
  const [filterCategory, setFilterCategory] = useState("Todos");
  const [filterSubject,  setFilterSubject]  = useState("Todos");

  const [form, setForm] = useState({
    subject:     "",
    description: "",
    errorType:   "Lei Seca" as EType,
    questionType: "Múltipla Escolha" as QType,
    // alternatives
    altA: "", altB: "", altC: "", altD: "", altE: "",
    correctAnswer: "a",
    // discursiva
    mirror: "",
    lastPage: "",
  });

  // Ctrl+Enter to save dialog
  useEffect(() => {
    if (!showDialog) return;
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter") handleAdd();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [showDialog, form]);

  const subjects = Array.from(new Set(STUDY_SESSIONS.map((s) => s.subject)));

  const filtered = useMemo(() => {
    return errorEntries.filter((e) => {
      const catOk = filterCategory === "Todos" || e.category === filterCategory;
      const subOk = filterSubject  === "Todos" || e.subject  === filterSubject;
      return catOk && subOk;
    });
  }, [errorEntries, filterCategory, filterSubject]);

  const stats = useMemo(() => ({
    total:     errorEntries.length,
    leiseca:   errorEntries.filter((e) => e.errorType === "Lei Seca").length,
    atencao:   errorEntries.filter((e) => e.errorType === "Atenção").length,
    teoria:    errorEntries.filter((e) => e.errorType === "Teoria").length,
  }), [errorEntries]);

  const handleAdd = async () => {
    if (!form.subject || !form.description) { toast.error("Preencha matéria e descrição"); return; }
    const category = ["Regimento Interno CD", "Dir. Administrativo", "Dir. Constitucional"].includes(form.subject)
      ? "Legislação" : "Geral";
    const id = `err-${Date.now()}`;
    addErrorEntry({ subject: form.subject, description: form.description, errorType: form.errorType, lastPage: form.lastPage });
    try {
      await addEntryMut.mutateAsync({ id, subject: form.subject, description: form.description, errorType: form.errorType, category: category as any, lastPage: form.lastPage });
    } catch {}
    setForm({ subject: "", description: "", errorType: "Lei Seca", questionType: "Múltipla Escolha", altA:"",altB:"",altC:"",altD:"",altE:"", correctAnswer:"a", mirror:"", lastPage:"" });
    setShowDialog(false);
    toast.success("Erro registrado!");
  };

  const handleDelete = async (id: string) => {
    deleteErrorEntry(id);
    try { await deleteEntryMut.mutateAsync({ id }); } catch {}
    toast.success("Removido");
  };

  const typeColor: Record<EType, string> = {
    "Lei Seca": "status-red",
    "Atenção":  "status-yellow",
    "Teoria":   "rgba(155,89,182,0.8)",
  };

  return (
    <Layout>
      <div className="container mx-auto py-8 px-4 max-w-5xl fade-in">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 style={{ fontSize: "2rem", fontWeight: 800, letterSpacing: "-0.03em",
              background: "linear-gradient(135deg, #fff, rgba(255,107,53,0.9))",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            }}>
              Caderno de Erros
            </h1>
            <p style={{ color: "var(--muted-foreground)", fontSize: "0.875rem" }}>
              Registre, analise e supere seus erros
            </p>
          </div>
          <button
            onClick={() => setShowDialog(true)}
            className="btn-coral flex items-center gap-2 px-5 py-2.5 rounded-xl self-start"
          >
            <Plus size={16} /> Novo Erro
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {[
            { label: "Total",    value: stats.total,   color: "var(--coral)" },
            { label: "Lei Seca", value: stats.leiseca, color: "#e74c3c" },
            { label: "Atenção",  value: stats.atencao, color: "var(--gold)" },
            { label: "Teoria",   value: stats.teoria,  color: "#9b59b6" },
          ].map(({ label, value, color }) => (
            <div key={label} className="glass-card p-4 text-center">
              <p style={{ fontSize: "0.75rem", color: "var(--muted-foreground)", marginBottom: "4px" }}>{label}</p>
              <p style={{ fontSize: "1.75rem", fontWeight: 800, color }}>{value}</p>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="glass-card p-4 mb-6">
          <div className="flex items-center gap-2 mb-3">
            <Filter size={15} style={{ color: "var(--muted-foreground)" }} />
            <span style={{ fontSize: "0.875rem", fontWeight: 600 }}>Filtros</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
              <SelectContent>
                {["Todos","Legislação","Geral"].map(v => <SelectItem key={v} value={v}>{v}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filterSubject} onValueChange={setFilterSubject}>
              <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Todos">Todos</SelectItem>
                {subjects.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Error list */}
        <div className="space-y-3">
          {filtered.length === 0 && (
            <div className="glass-card p-12 text-center">
              <AlertCircle size={40} style={{ color: "var(--muted-foreground)", margin: "0 auto 12px" }} />
              <p style={{ color: "var(--muted-foreground)" }}>Nenhum erro registrado ainda.</p>
            </div>
          )}
          {filtered.map((err) => (
            <div key={err.id} className="glass-card p-5 fade-in">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <span
                      className="px-2.5 py-0.5 rounded-full text-xs font-semibold"
                      style={{
                        background: err.errorType === "Lei Seca" ? "rgba(231,76,60,0.15)" : err.errorType === "Atenção" ? "rgba(230,184,0,0.15)" : "rgba(155,89,182,0.15)",
                        color: err.errorType === "Lei Seca" ? "#e74c3c" : err.errorType === "Atenção" ? "var(--gold)" : "#9b59b6",
                        border: `1px solid ${err.errorType === "Lei Seca" ? "rgba(231,76,60,0.3)" : err.errorType === "Atenção" ? "rgba(230,184,0,0.3)" : "rgba(155,89,182,0.3)"}`,
                      }}
                    >
                      {err.errorType}
                    </span>
                    <span style={{ fontSize: "0.8rem", color: "var(--coral)", fontWeight: 600 }}>
                      {err.subject}
                    </span>
                    <span style={{ fontSize: "0.75rem", color: "var(--muted-foreground)" }}>
                      {new Date(err.date).toLocaleDateString("pt-BR")}
                    </span>
                  </div>
                  <p style={{ fontSize: "0.9rem", lineHeight: 1.5 }}>{err.description}</p>
                  {err.lastPage && (
                    <p style={{ fontSize: "0.75rem", color: "var(--muted-foreground)", marginTop: "6px" }}>
                      📄 Pág. {err.lastPage}
                    </p>
                  )}
                </div>
                <button
                  onClick={() => handleDelete(err.id)}
                  className="flex-shrink-0 p-2 rounded-lg transition-all duration-200"
                  style={{ color: "var(--muted-foreground)", background: "rgba(231,76,60,0.1)" }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.color = "#e74c3c"; (e.currentTarget as HTMLElement).style.background = "rgba(231,76,60,0.2)"; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.color = "var(--muted-foreground)"; (e.currentTarget as HTMLElement).style.background = "rgba(231,76,60,0.1)"; }}
                >
                  <Trash2 size={15} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent style={{ background: "#1e0835", border: "1px solid rgba(200,80,120,0.3)", maxWidth: "560px" }}>
          <DialogHeader>
            <DialogTitle style={{ color: "var(--coral)" }}>Registrar Erro</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {/* Subject */}
            <div>
              <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Matéria *</Label>
              <Select value={form.subject} onValueChange={(v) => setForm(f => ({ ...f, subject: v }))}>
                <SelectTrigger className="mt-1 rounded-xl"><SelectValue placeholder="Selecione..." /></SelectTrigger>
                <SelectContent>
                  {subjects.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            {/* Type */}
            <div>
              <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Tipo de Erro *</Label>
              <Select value={form.errorType} onValueChange={(v) => setForm(f => ({ ...f, errorType: v as EType }))}>
                <SelectTrigger className="mt-1 rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {(["Lei Seca","Atenção","Teoria"] as EType[]).map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            {/* Question type */}
            <div>
              <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Tipo de Questão</Label>
              <Select value={form.questionType} onValueChange={(v) => setForm(f => ({ ...f, questionType: v as QType }))}>
                <SelectTrigger className="mt-1 rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {(["Múltipla Escolha","Verdadeiro/Falso","Discursiva"] as QType[]).map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            {/* Description */}
            <div>
              <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>
                {form.questionType === "Discursiva" ? "Enunciado *" : "Descrição do Erro *"}
              </Label>
              <textarea
                value={form.description}
                onChange={(e) => setForm(f => ({ ...f, description: e.target.value }))}
                placeholder={form.questionType === "Discursiva" ? "Enunciado da questão..." : "O que você errou?"}
                rows={3}
                style={{
                  width: "100%", marginTop: "4px", resize: "vertical",
                  background: "rgba(90,20,60,0.4)", border: "1px solid rgba(200,80,120,0.25)",
                  borderRadius: "0.75rem", padding: "10px 12px", color: "var(--foreground)",
                  fontSize: "0.875rem", fontFamily: "inherit",
                }}
              />
            </div>

            {/* Discursiva: mirror */}
            {form.questionType === "Discursiva" && (
              <div>
                <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Espelho de Resposta</Label>
                <textarea
                  value={form.mirror}
                  onChange={(e) => setForm(f => ({ ...f, mirror: e.target.value }))}
                  placeholder="Resposta esperada / gabarito..."
                  rows={3}
                  style={{
                    width: "100%", marginTop: "4px", resize: "vertical",
                    background: "rgba(90,20,60,0.4)", border: "1px solid rgba(200,80,120,0.25)",
                    borderRadius: "0.75rem", padding: "10px 12px", color: "var(--foreground)",
                    fontSize: "0.875rem", fontFamily: "inherit",
                  }}
                />
              </div>
            )}

            {/* MC / VF alternatives */}
            {form.questionType !== "Discursiva" && (
              <div>
                <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Alternativas</Label>
                <div className="space-y-2 mt-1">
                  {(["a","b"] as const).map(k => (
                    <div key={k} className="flex items-center gap-2">
                      <span style={{ width: "20px", fontWeight: 700, color: "var(--coral)", flexShrink: 0, textTransform: "uppercase" }}>{k})</span>
                      <Input
                        value={(form as any)[`alt${k.toUpperCase()}`]}
                        onChange={(e) => setForm(f => ({ ...f, [`alt${k.toUpperCase()}`]: e.target.value }))}
                        placeholder={`Alternativa ${k.toUpperCase()}`}
                        className="rounded-xl"
                      />
                    </div>
                  ))}
                  {form.questionType === "Múltipla Escolha" && (["c","d","e"] as const).map(k => (
                    <div key={k} className="flex items-center gap-2">
                      <span style={{ width: "20px", fontWeight: 700, color: "var(--coral)", flexShrink: 0, textTransform: "uppercase" }}>{k})</span>
                      <Input
                        value={(form as any)[`alt${k.toUpperCase()}`]}
                        onChange={(e) => setForm(f => ({ ...f, [`alt${k.toUpperCase()}`]: e.target.value }))}
                        placeholder={`Alternativa ${k.toUpperCase()}`}
                        className="rounded-xl"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Last page */}
            <div>
              <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Página / Referência (opcional)</Label>
              <Input
                value={form.lastPage}
                onChange={(e) => setForm(f => ({ ...f, lastPage: e.target.value }))}
                placeholder="Ex: pág. 42"
                className="mt-1 rounded-xl"
              />
            </div>

            <p style={{ fontSize: "0.7rem", color: "var(--muted-foreground)" }}>
              💡 Ctrl+Enter para salvar rapidamente
            </p>
          </div>

          <DialogFooter>
            <button className="btn-glass px-4 py-2 rounded-xl text-sm" onClick={() => setShowDialog(false)}>Cancelar</button>
            <button className="btn-coral px-6 py-2 rounded-xl text-sm" onClick={handleAdd}>Registrar Erro</button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
