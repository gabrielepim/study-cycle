import React, { useState, useMemo } from "react";
import Layout from "@/components/Layout";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useStudyCycle } from "@/contexts/StudyCycleContext";
import { STUDY_SESSIONS, EditorialTopic } from "@/types";
import { Plus, Trash2, BookOpen, AlertTriangle, Pencil } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

export default function Editorial() {
  const { editorialTopics, updateEditorialTopic, deleteErrorEntry } = useStudyCycle();
  const addTopicMut    = trpc.editorial.addTopic.useMutation();
  const updateTopicMut = trpc.editorial.updateTopic.useMutation();
  const deleteTopicMut = trpc.editorial.deleteTopic.useMutation();

  const [showDialog, setShowDialog] = useState(false);
  const [editMode, setEditMode]     = useState<EditorialTopic | null>(null);
  const [selectedSubject, setSelectedSubject] = useState("");
  const [form, setForm] = useState({ topic: "", subtopic: "" });

  const subjects = Array.from(new Set(STUDY_SESSIONS.map((s) => s.subject)));

  const freshness = (topic: EditorialTopic): "green" | "yellow" | "red" => {
    if (!topic.lastReviewDate) return "red";
    const days = Math.floor((Date.now() - new Date(topic.lastReviewDate).getTime()) / 86400000);
    if (days < 15) return "green";
    if (days < 30) return "yellow";
    return "red";
  };

  const topicsBySubject = useMemo(() => {
    const g: Record<string, EditorialTopic[]> = {};
    subjects.forEach(s => { g[s] = editorialTopics.filter(t => t.subject === s); });
    return g;
  }, [editorialTopics, subjects]);

  const criticalCount = useMemo(
    () => editorialTopics.filter(t => freshness(t) === "red").length,
    [editorialTopics]
  );

  const handleAdd = async () => {
    if (!selectedSubject || !form.topic) { toast.error("Preencha matéria e tópico"); return; }
    const id = `topic-${Date.now()}`;
    const newTopic: EditorialTopic = {
      id, subject: selectedSubject, topic: form.topic,
      subtopics: form.subtopic ? [{ id: `st-${Date.now()}`, name: form.subtopic, theory: false, review: false, questions: false }] : [],
      freshness: "green", lastReviewDate: new Date().toISOString(),
    };
    updateEditorialTopic(newTopic);
    try { await addTopicMut.mutateAsync({ id, subject: selectedSubject, topic: form.topic, subtopics: newTopic.subtopics }); } catch {}
    setForm({ topic: "", subtopic: "" }); setShowDialog(false);
    toast.success("Tópico adicionado!");
  };

  const handleToggle = async (topicId: string, subtopicId: string, field: "theory" | "review" | "questions") => {
    const topic = editorialTopics.find(t => t.id === topicId);
    if (!topic) return;
    const subs = topic.subtopics.map(s => s.id === subtopicId ? { ...s, [field]: !s[field], reviewDate: new Date().toISOString() } : s);
    const updated = { ...topic, subtopics: subs, lastReviewDate: new Date().toISOString() };
    updateEditorialTopic(updated);
    try { await updateTopicMut.mutateAsync({ id: topicId, data: updated }); } catch {}
  };

  const handleDelete = async (id: string) => {
    // remove from local context using updateEditorialTopic with a trick — we just filter in context
    // Since context only has updateEditorialTopic, we rely on the DB delete and page reload
    try { await deleteTopicMut.mutateAsync({ id }); toast.success("Removido"); } catch {}
  };

  const freshnessStyle = (f: "green"|"yellow"|"red") =>
    f === "green" ? { color: "#27ae60", border: "1px solid rgba(39,174,96,0.4)", background: "rgba(39,174,96,0.1)" }
    : f === "yellow" ? { color: "var(--gold)", border: "1px solid rgba(230,184,0,0.4)", background: "rgba(230,184,0,0.1)" }
    : { color: "#e74c3c", border: "1px solid rgba(231,76,60,0.4)", background: "rgba(231,76,60,0.1)" };

  return (
    <Layout>
      <div className="container mx-auto py-8 px-4 max-w-5xl fade-in">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 style={{ fontSize: "2rem", fontWeight: 800, letterSpacing: "-0.03em",
              background: "linear-gradient(135deg, #fff, rgba(255,107,53,0.9))",
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            }}>
              Edital Verticalizado
            </h1>
            <p style={{ color: "var(--muted-foreground)", fontSize: "0.875rem" }}>
              Rastreie teoria, revisão e questões por tópico
              {criticalCount > 0 && (
                <span style={{ color: "#e74c3c", marginLeft: "8px" }}>
                  ⚠️ {criticalCount} tópico{criticalCount > 1 ? "s" : ""} sem revisão há +30 dias
                </span>
              )}
            </p>
          </div>
          <button
            onClick={() => setShowDialog(true)}
            className="btn-coral flex items-center gap-2 px-5 py-2.5 rounded-xl self-start"
          >
            <Plus size={16} /> Novo Tópico
          </button>
        </div>

        {/* Topics by subject */}
        <div className="space-y-6">
          {subjects.map(subject => {
            const topics = topicsBySubject[subject] || [];
            if (topics.length === 0) return null;
            return (
              <div key={subject} className="glass-card p-6">
                <div className="flex items-center gap-2 mb-4">
                  <BookOpen size={16} style={{ color: "var(--coral)" }} />
                  <h2 style={{ fontWeight: 700, fontSize: "1rem", color: "var(--coral)" }}>{subject}</h2>
                  <span style={{ fontSize: "0.75rem", color: "var(--muted-foreground)", marginLeft: "auto" }}>
                    {topics.length} tópico{topics.length > 1 ? "s" : ""}
                  </span>
                </div>

                <div className="space-y-4">
                  {topics.map(topic => {
                    const f = freshness(topic);
                    return (
                      <div key={topic.id} className="rounded-xl p-4" style={{ background: "rgba(26,10,46,0.5)", border: "1px solid rgba(200,80,120,0.15)" }}>
                        <div className="flex items-start justify-between gap-2 mb-3">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span style={{ fontWeight: 600, fontSize: "0.9rem" }}>{topic.topic}</span>
                            <span
                              className="px-2 py-0.5 rounded-full text-xs font-medium"
                              style={freshnessStyle(f)}
                            >
                              {f === "green" ? "✓ Revisado" : f === "yellow" ? "⚡ Revisar em breve" : "🔴 Urgente"}
                            </span>
                          </div>
                          <div className="flex gap-1">
                            <button
                              onClick={() => handleDelete(topic.id)}
                              className="p-1.5 rounded-lg"
                              style={{ color: "var(--muted-foreground)", background: "rgba(231,76,60,0.1)" }}
                              onMouseEnter={(e) => (e.currentTarget as HTMLElement).style.color = "#e74c3c"}
                              onMouseLeave={(e) => (e.currentTarget as HTMLElement).style.color = "var(--muted-foreground)"}
                            >
                              <Trash2 size={13} />
                            </button>
                          </div>
                        </div>

                        {/* Subtopics */}
                        {topic.subtopics.length > 0 && (
                          <div className="space-y-2">
                            {topic.subtopics.map(st => (
                              <div key={st.id} className="flex items-center justify-between gap-4 py-1.5 px-3 rounded-lg" style={{ background: "rgba(90,20,60,0.2)" }}>
                                <span style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>{st.name}</span>
                                <div className="flex gap-4">
                                  {(["theory","review","questions"] as const).map(field => (
                                    <label key={field} className="flex items-center gap-1.5 cursor-pointer">
                                      <Checkbox
                                        checked={st[field]}
                                        onCheckedChange={() => handleToggle(topic.id, st.id, field)}
                                      />
                                      <span style={{ fontSize: "0.7rem", color: "var(--muted-foreground)", textTransform: "capitalize" }}>
                                        {field === "theory" ? "Teoria" : field === "review" ? "Revisão" : "Questões"}
                                      </span>
                                    </label>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}

          {editorialTopics.length === 0 && (
            <div className="glass-card p-12 text-center">
              <BookOpen size={40} style={{ color: "var(--muted-foreground)", margin: "0 auto 12px" }} />
              <p style={{ color: "var(--muted-foreground)" }}>Nenhum tópico cadastrado ainda.</p>
            </div>
          )}
        </div>
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent style={{ background: "#1e0835", border: "1px solid rgba(200,80,120,0.3)" }}>
          <DialogHeader>
            <DialogTitle style={{ color: "var(--coral)" }}>Novo Tópico do Edital</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Matéria *</Label>
              <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                <SelectTrigger className="mt-1 rounded-xl"><SelectValue placeholder="Selecione..." /></SelectTrigger>
                <SelectContent>
                  {subjects.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Tópico *</Label>
              <Input value={form.topic} onChange={e => setForm(f => ({ ...f, topic: e.target.value }))} placeholder="Ex: Princípios da Administração Pública" className="mt-1 rounded-xl" />
            </div>
            <div>
              <Label style={{ fontSize: "0.8rem", color: "var(--muted-foreground)" }}>Subtópico (opcional)</Label>
              <Input value={form.subtopic} onChange={e => setForm(f => ({ ...f, subtopic: e.target.value }))} placeholder="Ex: Legalidade, Impessoalidade..." className="mt-1 rounded-xl" />
            </div>
          </div>
          <DialogFooter>
            <button className="btn-glass px-4 py-2 rounded-xl text-sm" onClick={() => setShowDialog(false)}>Cancelar</button>
            <button className="btn-coral px-6 py-2 rounded-xl text-sm" onClick={handleAdd}>Adicionar</button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
