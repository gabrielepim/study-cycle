import React, { createContext, useContext, useCallback } from "react";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import {
  CycleProgress,
  ProductivityRecord,
  ErrorEntry,
  EditorialTopic,
  WeekendBlock,
  Medal,
  StudyStreak,
  Argument,
  STUDY_SESSIONS,
  STORAGE_KEYS,
  MEDAL_DEFINITIONS,
} from "@/types";

interface StudyCycleContextType {
  // Ciclo
  cycleProgress: CycleProgress;
  currentSession: (typeof STUDY_SESSIONS)[0] | null;
  completeSession: (sessionId: number) => void;
  resetCycle: () => void;

  // Produtividade
  productivityRecords: ProductivityRecord[];
  addProductivityRecord: (record: Omit<ProductivityRecord, "id">) => void;

  // Erros
  errorEntries: ErrorEntry[];
  addErrorEntry: (error: Omit<ErrorEntry, "id" | "date" | "category">) => void;
  deleteErrorEntry: (id: string) => void;

  // Editorial
  editorialTopics: EditorialTopic[];
  updateEditorialTopic: (topic: EditorialTopic) => void;

  // Blocos de Fim de Semana
  weekendBlocks: WeekendBlock[];
  addWeekendBlock: (block: Omit<WeekendBlock, "id">) => void;
  completeWeekendBlock: (id: string) => void;

  // Medalhas e Gamificação
  unlockedMedals: Medal[];
  studyStreak: StudyStreak;

  // Argumentos e Citações
  arguments: Argument[];
  addArgument: (argument: Omit<Argument, "id" | "createdDate">) => void;
  deleteArgument: (id: string) => void;
}

const StudyCycleContext = createContext<StudyCycleContextType | undefined>(undefined);

export function StudyCycleProvider({ children }: { children: React.ReactNode }) {
  const [cycleProgress, setCycleProgress] = useLocalStorage<CycleProgress>(
    STORAGE_KEYS.CYCLE_PROGRESS,
    {
      currentSessionId: 1,
      completedSessions: [],
      totalSessions: STUDY_SESSIONS.length,
      cycleStartDate: new Date().toISOString(),
    }
  );

  const [productivityRecords, setProductivityRecords] = useLocalStorage<ProductivityRecord[]>(
    STORAGE_KEYS.PRODUCTIVITY_RECORDS,
    []
  );

  const [errorEntries, setErrorEntries] = useLocalStorage<ErrorEntry[]>(
    STORAGE_KEYS.ERROR_ENTRIES,
    []
  );

  const [editorialTopics, setEditorialTopics] = useLocalStorage<EditorialTopic[]>(
    STORAGE_KEYS.EDITORIAL_TOPICS,
    []
  );

  const [weekendBlocks, setWeekendBlocks] = useLocalStorage<WeekendBlock[]>(
    STORAGE_KEYS.WEEKEND_BLOCKS,
    []
  );

  const [unlockedMedals, setUnlockedMedals] = useLocalStorage<Medal[]>(
    STORAGE_KEYS.MEDALS,
    []
  );

  const [studyStreak, setStudyStreak] = useLocalStorage<StudyStreak>(
    STORAGE_KEYS.STUDY_STREAK,
    {
      currentStreak: 0,
      longestStreak: 0,
    }
  );

  const [savedArguments, setSavedArguments] = useLocalStorage<Argument[]>(
    STORAGE_KEYS.ARGUMENTS,
    []
  );

  const currentSession = STUDY_SESSIONS.find((s) => s.id === cycleProgress.currentSessionId) || null;

  const completeSession = useCallback(
    (sessionId: number) => {
      setCycleProgress((prev) => {
        const completed = new Set(prev.completedSessions);
        completed.add(sessionId);

        let nextSessionId = sessionId + 1;
        if (nextSessionId > STUDY_SESSIONS.length) {
          nextSessionId = 1; // Reinicia o ciclo
        }

        return {
          ...prev,
          currentSessionId: nextSessionId,
          completedSessions: Array.from(completed),
        };
      });
    },
    [setCycleProgress]
  );

  const resetCycle = useCallback(() => {
    setCycleProgress({
      currentSessionId: 1,
      completedSessions: [],
      totalSessions: STUDY_SESSIONS.length,
      cycleStartDate: new Date().toISOString(),
    });
  }, [setCycleProgress]);

  const addProductivityRecord = useCallback(
    (record: Omit<ProductivityRecord, "id">) => {
      setProductivityRecords((prev) => [
        ...prev,
        {
          ...record,
          id: `prod-${Date.now()}`,
        },
      ]);

      // Verificar e desbloquear medalhas
      const newRecords = [...productivityRecords, { ...record, id: `prod-${Date.now()}` }];
      checkMedalUnlock(newRecords);

      // Atualizar streak
      updateStudyStreak();
    },
    [setProductivityRecords, productivityRecords, unlockedMedals]
  );

  const addErrorEntry = useCallback(
    (error: Omit<ErrorEntry, "id" | "date" | "category">) => {
      const category = ["Regimento Interno CD", "Dir. Administrativo", "Dir. Constitucional"].includes(error.subject)
        ? "Legislação"
        : "Geral";

      setErrorEntries((prev) => [
        ...prev,
        {
          ...error,
          id: `err-${Date.now()}`,
          date: new Date().toISOString(),
          category,
        },
      ]);
    },
    [setErrorEntries]
  );

  const deleteErrorEntry = useCallback(
    (id: string) => {
      setErrorEntries((prev) => prev.filter((e) => e.id !== id));
    },
    [setErrorEntries]
  );

  const updateEditorialTopic = useCallback(
    (topic: EditorialTopic) => {
      setEditorialTopics((prev) => {
        const existing = prev.findIndex((t) => t.id === topic.id);
        if (existing >= 0) {
          const updated = [...prev];
          updated[existing] = topic;
          return updated;
        }
        return [...prev, topic];
      });
    },
    [setEditorialTopics]
  );

  const addWeekendBlock = useCallback(
    (block: Omit<WeekendBlock, "id">) => {
      setWeekendBlocks((prev) => [
        ...prev,
        {
          ...block,
          id: `weekend-${Date.now()}`,
        },
      ]);
    },
    [setWeekendBlocks]
  );

  const completeWeekendBlock = useCallback(
    (id: string) => {
      setWeekendBlocks((prev) =>
        prev.map((b) => (b.id === id ? { ...b, completed: true } : b))
      );
    },
    [setWeekendBlocks]
  );

  const checkMedalUnlock = useCallback(
    (records: ProductivityRecord[]) => {
      const newMedals: Medal[] = [];

      // Verificar "Centésimo" (100 questões)
      const totalQuestions = records.reduce((sum, r) => sum + r.questionsAttempted, 0);
      if (totalQuestions >= 100 && !unlockedMedals.some((m) => m.id === "hundred-questions")) {
        newMedals.push({
          ...MEDAL_DEFINITIONS.find((m) => m.id === "hundred-questions")!,
          unlockedDate: new Date().toISOString(),
        });
      }

      // Verificar "Coruja Noturna" (10 sessões)
      if (records.length >= 10 && !unlockedMedals.some((m) => m.id === "night-owl")) {
        newMedals.push({
          ...MEDAL_DEFINITIONS.find((m) => m.id === "night-owl")!,
          unlockedDate: new Date().toISOString(),
        });
      }

      // Verificar "Sessão Perfeita" (100% acurácia)
      const perfectSession = records.some((r) => r.successRate === 100);
      if (perfectSession && !unlockedMedals.some((m) => m.id === "perfect-session")) {
        newMedals.push({
          ...MEDAL_DEFINITIONS.find((m) => m.id === "perfect-session")!,
          unlockedDate: new Date().toISOString(),
        });
      }

      if (newMedals.length > 0) {
        setUnlockedMedals((prev) => [...prev, ...newMedals]);
      }
    },
    [unlockedMedals, setUnlockedMedals]
  );

  const updateStudyStreak = useCallback(() => {
    const today = new Date().toDateString();
    const lastStudyDate = studyStreak.lastStudyDate ? new Date(studyStreak.lastStudyDate).toDateString() : null;

    if (lastStudyDate === today) {
      // Já estudou hoje
      return;
    }

    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);

    if (lastStudyDate === yesterday.toDateString()) {
      // Continuou a sequência
      const newStreak = studyStreak.currentStreak + 1;
      setStudyStreak({
        currentStreak: newStreak,
        longestStreak: Math.max(newStreak, studyStreak.longestStreak),
        lastStudyDate: new Date().toISOString(),
      });

      // Verificar medalha de "Consistência" (7 dias)
      if (newStreak === 7 && !unlockedMedals.some((m) => m.id === "seven-days")) {
        setUnlockedMedals((prev) => [
          ...prev,
          {
            ...MEDAL_DEFINITIONS.find((m) => m.id === "seven-days")!,
            unlockedDate: new Date().toISOString(),
          },
        ]);
      }
    } else {
      // Reiniciar sequência
      setStudyStreak({
        currentStreak: 1,
        longestStreak: studyStreak.longestStreak,
        lastStudyDate: new Date().toISOString(),
      });
    }
  }, [studyStreak, setStudyStreak, unlockedMedals, setUnlockedMedals]);

  const addArgument = useCallback(
    (argument: Omit<Argument, "id" | "createdDate">) => {
      setSavedArguments((prev) => [
        ...prev,
        {
          ...argument,
          id: `arg-${Date.now()}`,
          createdDate: new Date().toISOString(),
        },
      ]);
    },
    [setSavedArguments]
  );

  const deleteArgument = useCallback(
    (id: string) => {
      setSavedArguments((prev) => prev.filter((a) => a.id !== id));
    },
    [setSavedArguments]
  );

  const value: StudyCycleContextType = {
    cycleProgress,
    currentSession,
    completeSession,
    resetCycle,
    productivityRecords,
    addProductivityRecord,
    errorEntries,
    addErrorEntry,
    deleteErrorEntry,
    editorialTopics,
    updateEditorialTopic,
    weekendBlocks,
    addWeekendBlock,
    completeWeekendBlock,
    unlockedMedals,
    studyStreak,
    arguments: savedArguments,
    addArgument,
    deleteArgument,
  };

  return (
    <StudyCycleContext.Provider value={value}>
      {children}
    </StudyCycleContext.Provider>
  );
}

export function useStudyCycle() {
  const context = useContext(StudyCycleContext);
  if (!context) {
    throw new Error("useStudyCycle deve ser usado dentro de StudyCycleProvider");
  }
  return context;
}
