import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { StudyCycleProvider } from "./contexts/StudyCycleContext";
import StudyCycle from "./pages/StudyCycle";
import Dashboard from "./pages/Dashboard";
import ErrorNotebook from "./pages/ErrorNotebook";
import Editorial from "./pages/Editorial";
import Export from "./pages/Export";
import Arguments from "./pages/Arguments";
import ExamQuestions from "./pages/ExamQuestions";
function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={StudyCycle} />
      <Route path={"/dashboard"} component={Dashboard} />
      <Route path={"/erros"} component={ErrorNotebook} />
      <Route path={"/questoes"} component={ExamQuestions} />
      <Route path={"/edital"} component={Editorial} />
      <Route path={"/argumentos"} component={Arguments} />
      <Route path={"/exportar"} component={Export} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        switchable
      >
        <StudyCycleProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </StudyCycleProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
