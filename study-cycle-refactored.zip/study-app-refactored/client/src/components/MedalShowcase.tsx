import React, { useMemo } from "react";
import { Card } from "@/components/ui/card";
import { useStudyCycle } from "@/contexts/StudyCycleContext";
import { Medal, MEDAL_DEFINITIONS, STUDY_SESSIONS } from "@/types";
import { Lock } from "lucide-react";

export default function MedalShowcase() {
  const { productivityRecords, errorEntries, unlockedMedals } = useStudyCycle();

  const medalProgress = useMemo(() => {
    const medals: Record<string, Medal> = {};

    // Inicializar com definições
    MEDAL_DEFINITIONS.forEach((def) => {
      medals[def.id] = { ...def, progress: 0 };
    });

    // Calcular progresso de cada medalha
    const totalQuestions = productivityRecords.reduce((sum, r) => sum + r.questionsAttempted, 0);
    medals["hundred-questions"].progress = Math.min((totalQuestions / 100) * 100, 100);

    const sessionsCompleted = productivityRecords.length;
    medals["night-owl"].progress = Math.min((sessionsCompleted / 10) * 100, 100);

    // Verificar legislação
    const legislationErrors = errorEntries.filter((e) => e.category === "Legislação");
    const legislationRecords = productivityRecords.filter((r) =>
      ["Regimento Interno CD", "Dir. Administrativo", "Dir. Constitucional"].includes(r.sessionName)
    );

    if (legislationRecords.length > 0) {
      const legislationAccuracy =
        legislationRecords.reduce((sum, r) => sum + r.successRate, 0) / legislationRecords.length;
      medals["legislation-master"].progress = legislationAccuracy;
    }

    // Verificar sessão perfeita
    const perfectSessions = productivityRecords.filter((r) => r.successRate === 100);
    if (perfectSessions.length > 0) {
      medals["perfect-session"].progress = 100;
    }

    return medals;
  }, [productivityRecords, errorEntries]);

  const isMedalUnlocked = (medalId: string) => {
    return unlockedMedals?.some((m) => m.id === medalId) || false;
  };

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold mb-4">Medalhas e Conquistas</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
          {MEDAL_DEFINITIONS.map((medal) => {
            const isUnlocked = isMedalUnlocked(medal.id);
            const progress = medalProgress[medal.id]?.progress || 0;

            return (
              <div key={medal.id} className="relative">
                <Card
                  className={`p-4 flex flex-col items-center justify-center aspect-square transition-all duration-300 ${
                    isUnlocked
                      ? "bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border-yellow-500/50"
                      : "bg-muted/50 border-muted-foreground/20 opacity-60"
                  }`}
                >
                  <div className="text-4xl mb-2">{medal.icon}</div>
                  <p className="text-xs font-semibold text-center line-clamp-2">{medal.name}</p>

                  {!isUnlocked && (
                    <div className="absolute top-2 right-2">
                      <Lock className="w-4 h-4 text-muted-foreground" />
                    </div>
                  )}

                  {!isUnlocked && progress > 0 && progress < 100 && (
                    <div className="w-full mt-2 h-1 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-yellow-400 to-orange-400 transition-all duration-300"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  )}
                </Card>

                {!isUnlocked && (
                  <p className="text-xs text-muted-foreground mt-2 text-center">
                    {Math.round(progress)}%
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Descrição das Medalhas */}
      <Card className="p-4 bg-blue-500/10 border-blue-500/20">
        <p className="text-sm text-muted-foreground">
          <span className="font-semibold text-blue-600 dark:text-blue-400">💡 Dica:</span> Desbloqueie
          medalhas completando desafios e mantendo a consistência nos estudos!
        </p>
      </Card>
    </div>
  );
}
