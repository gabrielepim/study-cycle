import React, { useMemo } from "react";
import { Card } from "@/components/ui/card";
import { useStudyCycle } from "@/contexts/StudyCycleContext";
import { TrendingDown, AlertTriangle } from "lucide-react";

export default function WeakPointsFilter() {
  const { productivityRecords } = useStudyCycle();

  const weakPoints = useMemo(() => {
    const accuracyBySubject: Record<string, { total: number; count: number }> = {};

    productivityRecords.forEach((record) => {
      if (!accuracyBySubject[record.sessionName]) {
        accuracyBySubject[record.sessionName] = { total: 0, count: 0 };
      }
      accuracyBySubject[record.sessionName].total += record.successRate;
      accuracyBySubject[record.sessionName].count += 1;
    });

    return Object.entries(accuracyBySubject)
      .map(([subject, data]) => ({
        subject,
        accuracy: Math.round((data.total / data.count) * 100) / 100,
        attempts: data.count,
      }))
      .sort((a, b) => a.accuracy - b.accuracy)
      .slice(0, 5);
  }, [productivityRecords]);

  const getAccuracyColor = (accuracy: number) => {
    if (accuracy >= 80) return "text-green-500";
    if (accuracy >= 60) return "text-yellow-500";
    return "text-red-500";
  };

  const getAccuracyBgColor = (accuracy: number) => {
    if (accuracy >= 80) return "bg-green-500/10 border-green-500/20";
    if (accuracy >= 60) return "bg-yellow-500/10 border-yellow-500/20";
    return "bg-red-500/10 border-red-500/20";
  };

  if (weakPoints.length === 0) {
    return (
      <Card className="p-6 shadow-sm">
        <h3 className="text-lg font-semibold mb-4">Filtro de Ponto Fraco</h3>
        <div className="text-center py-8 text-muted-foreground">
          <p>Nenhum registro de produtividade ainda.</p>
          <p className="text-sm mt-2">Complete algumas sessões para visualizar seus pontos fracos.</p>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6 shadow-sm">
      <div className="mb-4">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <TrendingDown className="w-5 h-5 text-red-500" />
          Filtro de Ponto Fraco
        </h3>
        <p className="text-sm text-muted-foreground mt-1">
          Seus 5 assuntos com menor taxa de acerto
        </p>
      </div>

      <div className="space-y-3">
        {weakPoints.map((point, index) => (
          <div
            key={point.subject}
            className={`p-4 rounded-lg border ${getAccuracyBgColor(point.accuracy)} transition-all duration-200`}
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-semibold text-sm">{index + 1}.</span>
                  <p className="font-semibold">{point.subject}</p>
                  {point.accuracy < 60 && (
                    <AlertTriangle className="w-4 h-4 text-red-500 flex-shrink-0" />
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  {point.attempts} tentativa{point.attempts > 1 ? "s" : ""}
                </p>
              </div>
              <div className="text-right">
                <p className={`text-2xl font-bold ${getAccuracyColor(point.accuracy)}`}>
                  {point.accuracy}%
                </p>
              </div>
            </div>

            {/* Barra de Progresso */}
            <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-300 ${
                  point.accuracy >= 80
                    ? "bg-green-500"
                    : point.accuracy >= 60
                    ? "bg-yellow-500"
                    : "bg-red-500"
                }`}
                style={{ width: `${point.accuracy}%` }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Recomendação */}
      <div className="mt-6 p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg">
        <p className="text-sm text-muted-foreground">
          <span className="font-semibold text-amber-600 dark:text-amber-400">🎯 Recomendação:</span> Foque
          em revisar e praticar mais questões dos assuntos listados acima para melhorar sua acurácia.
        </p>
      </div>
    </Card>
  );
}
