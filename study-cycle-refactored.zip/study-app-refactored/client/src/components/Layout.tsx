import React, { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Clock, BarChart3, BookOpen, AlertCircle, Menu, X,
  Download, Lightbulb, FileText, Brain,
} from "lucide-react";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isMobile, setIsMobile] = useState(false);
  const [brainDumpOpen, setBrainDumpOpen] = useState(false);
  const [brainDumpText, setBrainDumpText] = useState("");

  useEffect(() => {
    const check = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (mobile) setSidebarOpen(false);
    };
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);

  // Ctrl+B para Brain Dump
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "b") {
        e.preventDefault();
        setBrainDumpOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  const navItems = [
    { href: "/", label: "Ciclo de Estudos", icon: Clock },
    { href: "/dashboard", label: "Dashboard", icon: BarChart3 },
    { href: "/erros", label: "Caderno de Erros", icon: AlertCircle },
    { href: "/questoes", label: "Questões Concurso", icon: FileText },
    { href: "/edital", label: "Edital Verticalizado", icon: BookOpen },
    { href: "/argumentos", label: "Argumentos", icon: Lightbulb },
    { href: "/exportar", label: "Exportar Dados", icon: Download },
  ];

  const handleNavClick = () => {
    if (isMobile) setSidebarOpen(false);
  };

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: "var(--background)" }}>
      {/* Mobile overlay */}
      {isMobile && sidebarOpen && (
        <div
          className="mobile-overlay"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          flex flex-col flex-shrink-0 z-10
          ${isMobile ? "mobile-sidebar" + (sidebarOpen ? " open" : "") : ""}
          ${sidebarOpen ? "w-64" : "w-[72px]"}
          transition-all duration-300
        `}
        style={{
          background: "rgba(22, 8, 38, 0.96)",
          backdropFilter: "blur(20px)",
          borderRight: "1px solid rgba(200,80,120,0.15)",
          boxShadow: "4px 0 24px rgba(0,0,0,0.4)",
        }}
      >
        {/* Logo */}
        <div
          className="flex items-center justify-between px-4 py-5"
          style={{ borderBottom: "1px solid rgba(200,80,120,0.15)" }}
        >
          {sidebarOpen && (
            <div>
              <span style={{ color: "var(--coral)", fontWeight: 800, fontSize: "1.1rem", letterSpacing: "-0.02em" }}>
                Study
              </span>
              <span style={{ color: "var(--foreground)", fontWeight: 300, fontSize: "1.1rem" }}>
                Cycle
              </span>
            </div>
          )}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="ml-auto p-2 rounded-lg transition-all duration-200"
            style={{ color: "var(--muted-foreground)" }}
            onMouseEnter={(e) => (e.currentTarget.style.color = "var(--coral)")}
            onMouseLeave={(e) => (e.currentTarget.style.color = "var(--muted-foreground)")}
          >
            {sidebarOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {navItems.map(({ href, label, icon: Icon }) => {
            const active = location === href;
            return (
              <Link
                key={href}
                href={href}
                onClick={handleNavClick}
                className={`
                  flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 group
                  ${active ? "nav-active" : ""}
                `}
                style={
                  !active
                    ? { color: "var(--muted-foreground)" }
                    : {}
                }
                onMouseEnter={(e) => {
                  if (!active) {
                    (e.currentTarget as HTMLElement).style.background = "rgba(200,80,120,0.12)";
                    (e.currentTarget as HTMLElement).style.color = "var(--foreground)";
                  }
                }}
                onMouseLeave={(e) => {
                  if (!active) {
                    (e.currentTarget as HTMLElement).style.background = "";
                    (e.currentTarget as HTMLElement).style.color = "var(--muted-foreground)";
                  }
                }}
              >
                <Icon
                  size={18}
                  className="flex-shrink-0"
                  style={{ color: active ? "var(--coral)" : "inherit" }}
                />
                {sidebarOpen && (
                  <span style={{ fontSize: "0.875rem", fontWeight: active ? 600 : 400 }}>
                    {label}
                  </span>
                )}
                {active && sidebarOpen && (
                  <span
                    className="ml-auto w-1.5 h-1.5 rounded-full"
                    style={{ background: "var(--coral)" }}
                  />
                )}
              </Link>
            );
          })}
        </nav>

        {/* Brain Dump button */}
        <div className="p-3" style={{ borderTop: "1px solid rgba(200,80,120,0.15)" }}>
          <button
            onClick={() => setBrainDumpOpen(!brainDumpOpen)}
            className="flex items-center gap-3 w-full px-3 py-3 rounded-xl transition-all duration-200"
            style={{
              background: brainDumpOpen ? "rgba(255,107,53,0.15)" : "rgba(200,80,120,0.1)",
              color: brainDumpOpen ? "var(--coral)" : "var(--muted-foreground)",
              border: `1px solid ${brainDumpOpen ? "rgba(255,107,53,0.3)" : "rgba(200,80,120,0.15)"}`,
            }}
            title="Brain Dump (Ctrl+B)"
          >
            <Brain size={18} className="flex-shrink-0" />
            {sidebarOpen && (
              <span style={{ fontSize: "0.875rem", fontWeight: 500 }}>Brain Dump</span>
            )}
            {sidebarOpen && (
              <span
                className="ml-auto text-xs px-1.5 py-0.5 rounded"
                style={{ background: "rgba(200,80,120,0.2)", color: "var(--muted-foreground)", fontSize: "0.65rem" }}
              >
                Ctrl+B
              </span>
            )}
          </button>
        </div>
      </aside>

      {/* Main area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile top bar */}
        {isMobile && (
          <div
            className="flex items-center gap-3 px-4 py-3 flex-shrink-0"
            style={{ borderBottom: "1px solid rgba(200,80,120,0.15)", background: "rgba(22,8,38,0.95)" }}
          >
            <button
              onClick={() => setSidebarOpen(true)}
              style={{ color: "var(--muted-foreground)" }}
            >
              <Menu size={20} />
            </button>
            <span style={{ color: "var(--coral)", fontWeight: 700 }}>StudyCycle</span>
          </div>
        )}

        {/* Page content */}
        <main className="flex-1 overflow-auto">
          {children}
        </main>
      </div>

      {/* Brain Dump floating panel */}
      {brainDumpOpen && (
        <div
          className="fixed bottom-6 right-6 z-50 fade-in"
          style={{
            width: "340px",
            background: "rgba(30,8,53,0.96)",
            backdropFilter: "blur(20px)",
            border: "1px solid rgba(255,107,53,0.35)",
            borderRadius: "1rem",
            boxShadow: "0 20px 60px rgba(0,0,0,0.6), 0 0 30px rgba(255,107,53,0.1)",
            padding: "16px",
          }}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Brain size={16} style={{ color: "var(--coral)" }} />
              <span style={{ fontWeight: 600, fontSize: "0.875rem", color: "var(--coral)" }}>
                Brain Dump
              </span>
            </div>
            <button
              onClick={() => setBrainDumpOpen(false)}
              style={{ color: "var(--muted-foreground)" }}
            >
              <X size={16} />
            </button>
          </div>
          <textarea
            autoFocus
            value={brainDumpText}
            onChange={(e) => setBrainDumpText(e.target.value)}
            placeholder="Jogue seus pensamentos aqui... o timer continua rodando."
            style={{
              width: "100%",
              height: "180px",
              resize: "vertical",
              background: "rgba(90,20,60,0.3)",
              border: "1px solid rgba(200,80,120,0.25)",
              borderRadius: "0.5rem",
              padding: "10px 12px",
              color: "var(--foreground)",
              fontSize: "0.875rem",
              lineHeight: 1.6,
              fontFamily: "inherit",
            }}
          />
          <p style={{ fontSize: "0.7rem", color: "var(--muted-foreground)", marginTop: "8px" }}>
            Anotações temporárias — não interrompem o timer.
          </p>
        </div>
      )}
    </div>
  );
}
