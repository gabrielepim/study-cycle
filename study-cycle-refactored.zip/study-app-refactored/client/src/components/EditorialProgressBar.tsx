import React, { useMemo } from "react";
import { useStudyCycle } from "@/contexts/StudyCycleContext";
import { Card } from "@/components/ui/card";
import { CheckCircle2, AlertCircle } from "lucide-react";

export default function EditorialProgressBar() {
  const { editorialTopics } = useStudyCycle();

  const progress = useMemo(() => {
    if (editorialTopics.length === 0) return 0;

    const totalItems = editorialTopics.reduce((sum, topic) => {
      return sum + topic.subtopics.length * 3; // 3 itens por subtópico (Teoria, Revisão, Questões)
    }, 0);

    const completedItems = editorialTopics.reduce((sum, topic) => {
      return (
        sum +
        topic.subtopics.reduce((subtopicSum, subtopic) => {
          return subtopicSum + (subtopic.theory ? 1 : 0) + (subtopic.review ? 1 : 0) + (subtopic.questions ? 1 : 0);
        }, 0)
      );
    }, 0);

    return totalItems > 0 ? Math.round((completedItems / totalItems) * 100) : 0;
  }, [editorialTopics]);

  const topicsByStatus = useMemo(() => {
    const completed = editorialTopics.filter((t) => {
      return t.subtopics.every((s) => s.theory && s.review && s.questions);
    }).length;

    const inProgress = editorialTopics.filter((t) => {
      const hasCompleted = t.subtopics.some((s) => s.theory || s.review || s.questions);
      const isFullyCompleted = t.subtopics.every((s) => s.theory && s.review && s.questions);
      return hasCompleted && !isFullyCompleted;
    }).length;

    const notStarted = editorialTopics.length - completed - inProgress;

    return { completed, inProgress, notStarted };
  }, [editorialTopics]);

  return (
    <div className="space-y-4">
      {/* Barra Principal */}
      <Card className="p-4 shadow-sm">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-sm">Progresso do Edital</h3>
              <p className="text-xs text-muted-foreground mt-1">
                {topicsByStatus.completed} concluído{topicsByStatus.completed !== 1 ? "s" : ""} • {topicsByStatus.inProgress} em progresso • {topicsByStatus.notStarted} não iniciado
              </p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-primary">{progress}%</p>
            </div>
          </div>

          {/* Barra de Progresso */}
          <div className="w-full h-3 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-green-400 to-green-600 transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>

          {/* Legenda */}
          <div className="grid grid-cols-3 gap-2 text-xs">
            <div className="flex items-center gap-2 p-2 bg-green-500/10 rounded">
              <CheckCircle2 className="w-4 h-4 text-green-600" />
              <span>{topicsByStatus.completed} Concluído</span>
            </div>
            <div className="flex items-center gap-2 p-2 bg-yellow-500/10 rounded">
              <AlertCircle className="w-4 h-4 text-yellow-600" />
              <span>{topicsByStatus.inProgress} Em Progresso</span>
            </div>
            <div className="flex items-center gap-2 p-2 bg-red-500/10 rounded">
              <AlertCircle className="w-4 h-4 text-red-600" />
              <span>{topicsByStatus.notStarted} Não Iniciado</span>
            </div>
          </div>
        </div>
      </Card>

      {/* Dica */}
      {progress < 100 && (
        <Card className="p-3 bg-blue-500/10 border-blue-500/20">
          <p className="text-xs text-muted-foreground">
            <span className="font-semibold text-blue-600 dark:text-blue-400">💡 Dica:</span> Você está {progress}% do caminho! Continue marcando os tópicos conforme estuda.
          </p>
        </Card>
      )}

      {progress === 100 && (
        <Card className="p-3 bg-green-500/10 border-green-500/20">
          <p className="text-xs text-green-600 dark:text-green-400">
            <span className="font-semibold">🎉 Parabéns!</span> Você completou 100% do edital!
          </p>
        </Card>
      )}
    </div>
  );
}
