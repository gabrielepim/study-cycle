import { Plus, Minus } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface TimerDisplayProps {
  timeLeft: number;
  isRunning: boolean;
  onAddTime: (minutes: number) => void;
  onSubtractTime: (minutes: number) => void;
  compact?: boolean;
}

export default function TimerDisplay({
  timeLeft,
  isRunning,
  onAddTime,
  onSubtractTime,
  compact = false,
}: TimerDisplayProps) {
  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  if (compact) {
    return (
      <div className={`text-3xl font-mono font-bold text-accent ${isRunning ? 'timer-glow' : ''}`}>
        {formatTime(timeLeft)}
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center gap-4">
      <div className={`text-6xl font-mono font-bold text-accent transition-smooth ${isRunning ? 'timer-glow' : ''}`}>
        {formatTime(timeLeft)}
      </div>
      
      <div className="flex gap-2">
        <Button
          onClick={() => onSubtractTime(5)}
          size="sm"
          variant="outline"
          className="gap-1"
        >
          <Minus className="w-4 h-4" />
          5 min
        </Button>
        <Button
          onClick={() => onAddTime(5)}
          size="sm"
          variant="outline"
          className="gap-1"
        >
          <Plus className="w-4 h-4" />
          5 min
        </Button>
      </div>
    </div>
  );
}
