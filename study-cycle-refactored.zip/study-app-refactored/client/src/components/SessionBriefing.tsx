import React, { useState, useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useStudyCycle } from "@/contexts/StudyCycleContext";
import { STUDY_SESSIONS, ErrorEntry } from "@/types";
import { AlertCircle, CheckCircle2, Clock, BookOpen } from "lucide-react";
import { Card } from "@/components/ui/card";

interface SessionBriefingProps {
  open: boolean;
  onConfirm: (subject: string, focus: "Teoria" | "Questões" | "Revisão", duration: number) => void;
  onCancel: () => void;
}

export default function SessionBriefing({ open, onConfirm, onCancel }: SessionBriefingProps) {
  const { currentSession, errorEntries } = useStudyCycle();
  const [selectedSubject, setSelectedSubject] = useState(currentSession?.subject || "");
  const [selectedFocus, setSelectedFocus] = useState<"Teoria" | "Questões" | "Revisão">("Questões");

  // Detectar se é fim de semana
  const isWeekend = useMemo(() => {
    const today = new Date();
    const dayOfWeek = today.getDay();
    return dayOfWeek === 0 || dayOfWeek === 6; // 0 = Domingo, 6 = Sábado
  }, []);

  const suggestedDuration = isWeekend ? 180 : 120; // 3h nos finais de semana, 2h nos dias de semana

  // Atualizar quando a sessão atual mudar
  React.useEffect(() => {
    if (currentSession?.subject && open) {
      setSelectedSubject(currentSession.subject);
    }
  }, [currentSession, open]);

  const subjects = Array.from(new Set(STUDY_SESSIONS.map((s) => s.subject)));

  // Buscar últimos 3 erros da matéria selecionada
  const recentErrors = useMemo(() => {
    return errorEntries
      .filter((e) => e.subject === selectedSubject)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 3);
  }, [errorEntries, selectedSubject]);

  // Encontrar última parada
  const lastPage = useMemo(() => {
    const lastError = recentErrors.find((e) => e.lastPage);
    return lastError?.lastPage || null;
  }, [recentErrors]);

  const handleConfirm = () => {
    if (selectedSubject) {
      onConfirm(selectedSubject, selectedFocus, suggestedDuration);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onCancel()}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">O que vamos vencer hoje?</DialogTitle>
          {isWeekend && (
            <p className="text-sm text-amber-600 dark:text-amber-400 mt-2">
              🎯 Fim de semana detectado! Sessão sugerida: 3 horas (2h + 1h extra)
            </p>
          )}
        </DialogHeader>

        <div className="space-y-6">
          {/* Seleção de Matéria */}
          <div>
            <label className="text-sm font-medium mb-2 block">Próxima Matéria</label>
            <Select value={selectedSubject} onValueChange={setSelectedSubject}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Selecione uma matéria" />
              </SelectTrigger>
              <SelectContent>
                {subjects.map((subject) => (
                  <SelectItem key={subject} value={subject}>
                    {subject}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {currentSession && (
              <p className="text-xs text-muted-foreground mt-2">
                Sessão sugerida: {currentSession.name} - {currentSession.subject}
              </p>
            )}
          </div>

          {/* Foco de Estudo */}
          <div>
            <label className="text-sm font-medium mb-2 block flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              Qual é seu foco hoje?
            </label>
            <Select value={selectedFocus} onValueChange={(value: any) => setSelectedFocus(value)}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Teoria">📚 Teoria - Aprender novos conceitos</SelectItem>
                <SelectItem value="Questões">❓ Questões - Praticar exercícios</SelectItem>
                <SelectItem value="Revisão">🔄 Revisão - Revisar conteúdo aprendido</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Duração Sugerida */}
          <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg flex items-start gap-3">
            <Clock className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-blue-600 dark:text-blue-400 text-sm">Duração Sugerida</p>
              <p className="text-sm text-muted-foreground mt-1">
                {suggestedDuration === 180
                  ? "3 horas (2h da matéria + 1h extra para Discursiva ou Revisão Geral)"
                  : "2 horas"}
              </p>
            </div>
          </div>

          {/* Flash-Revisão */}
          {recentErrors.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-amber-500" />
                <p className="text-sm font-medium">Últimos Erros Registrados</p>
              </div>

              <div className="space-y-2 max-h-48 overflow-y-auto">
                {recentErrors.map((error) => (
                  <Card key={error.id} className="p-3 bg-muted/50 border-muted">
                    <div className="flex items-start gap-2">
                      <div className="flex-shrink-0 mt-0.5">
                        {error.errorType === "Lei Seca" ? (
                          <div className="w-2 h-2 rounded-full bg-red-500" />
                        ) : error.errorType === "Atenção" ? (
                          <div className="w-2 h-2 rounded-full bg-amber-500" />
                        ) : (
                          <div className="w-2 h-2 rounded-full bg-blue-500" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium text-foreground line-clamp-2">
                          {error.description}
                        </p>
                        <div className="flex items-center gap-2 mt-1 flex-wrap">
                          <span className="text-xs px-2 py-0.5 rounded-full bg-background text-foreground">
                            {error.errorType}
                          </span>
                          {error.lastPage && (
                            <span className="text-xs text-muted-foreground bg-background px-2 py-0.5 rounded">
                              📍 Parou em: {error.lastPage}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              {lastPage && (
                <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
                  <p className="text-sm text-green-600 dark:text-green-400">
                    <span className="font-semibold">📍 Última Parada:</span> Você parou em <span className="font-bold">{lastPage}</span>. Retome daqui!
                  </p>
                </div>
              )}
            </div>
          )}

          {recentErrors.length === 0 && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-green-500/10 border border-green-500/20">
              <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
              <p className="text-sm text-green-600 dark:text-green-400">
                Nenhum erro registrado para esta matéria. Ótimo trabalho!
              </p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onCancel}>
            Cancelar
          </Button>
          <Button onClick={handleConfirm} className="gap-2">
            <CheckCircle2 className="w-4 h-4" />
            Confirmar e Iniciar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
