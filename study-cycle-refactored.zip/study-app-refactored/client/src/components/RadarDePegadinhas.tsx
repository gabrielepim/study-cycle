import React, { useMemo } from "react";
import { Card } from "@/components/ui/card";
import { useStudyCycle } from "@/contexts/StudyCycleContext";
import { AlertTriangle, AlertCircle } from "lucide-react";

export default function RadarDePegadinhas() {
  const { errorEntries } = useStudyCycle();

  const pegadinhas = useMemo(() => {
    return errorEntries.filter((e) => e.errorType === "Lei Seca" || e.category === "Legislação");
  }, [errorEntries]);

  const pegadinhasBySubject = useMemo(() => {
    const grouped: Record<string, typeof pegadinhas> = {};
    pegadinhas.forEach((p) => {
      if (!grouped[p.subject]) {
        grouped[p.subject] = [];
      }
      grouped[p.subject].push(p);
    });
    return grouped;
  }, [pegadinhas]);

  if (pegadinhas.length === 0) {
    return (
      <Card className="p-6 shadow-sm">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-amber-500" />
          Radar de Pegadinhas
        </h3>
        <div className="text-center py-8">
          <AlertCircle className="w-12 h-12 mx-auto mb-2 text-green-500/50" />
          <p className="text-muted-foreground">Nenhuma pegadinha registrada. Ótimo trabalho!</p>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6 shadow-sm">
      <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
        <AlertTriangle className="w-5 h-5 text-amber-500" />
        Radar de Pegadinhas ({pegadinhas.length})
      </h3>

      <div className="space-y-4">
        {Object.entries(pegadinhasBySubject).map(([subject, errors]) => (
          <div key={subject} className="border-l-4 border-amber-500 pl-4">
            <p className="font-medium text-sm mb-2">{subject}</p>
            <div className="space-y-2">
              {errors.slice(0, 3).map((error) => (
                <div key={error.id} className="text-sm bg-amber-500/10 p-2 rounded">
                  <p className="text-foreground line-clamp-2">{error.description}</p>
                  {error.lastPage && (
                    <p className="text-xs text-muted-foreground mt-1">Parou em: {error.lastPage}</p>
                  )}
                </div>
              ))}
              {errors.length > 3 && (
                <p className="text-xs text-muted-foreground">+{errors.length - 3} mais...</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
