import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Send, Lightbulb } from 'lucide-react';
import { toast } from 'sonner';

interface BrainDumpInputProps {
  onSubmit: (note: string) => void;
  placeholder?: string;
}

export default function BrainDumpInput({ onSubmit, placeholder = "Anotação rápida..." }: BrainDumpInputProps) {
  const [note, setNote] = useState('');

  const handleSubmit = () => {
    if (note.trim()) {
      onSubmit(note);
      setNote('');
      toast.success('Anotação salva!', {
        icon: <Lightbulb className="w-4 h-4" />,
        duration: 2000,
      });
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSubmit();
    }
  };

  return (
    <div className="flex gap-2 items-center">
      <Input
        type="text"
        placeholder={placeholder}
        value={note}
        onChange={(e) => setNote(e.target.value)}
        onKeyDown={handleKeyDown}
        className="flex-1 glass dark:glass-dark"
      />
      <Button
        onClick={handleSubmit}
        size="sm"
        className="bg-accent hover:bg-accent/90 text-accent-foreground"
      >
        <Send className="w-4 h-4" />
      </Button>
    </div>
  );
}
