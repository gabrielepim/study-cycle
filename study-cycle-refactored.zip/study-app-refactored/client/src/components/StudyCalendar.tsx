import React, { useMemo } from "react";
import { Card } from "@/components/ui/card";
import { useStudyCycle } from "@/contexts/StudyCycleContext";

export default function StudyCalendar() {
  const { productivityRecords, studyStreak } = useStudyCycle();

  const studyDays = useMemo(() => {
    const days = new Set<string>();
    productivityRecords.forEach((record) => {
      const date = new Date(record.date).toDateString();
      days.add(date);
    });
    return days;
  }, [productivityRecords]);

  // Gerar últimos 12 semanas (84 dias)
  const weeks = useMemo(() => {
    const weeksArray: Date[][] = [];
    const today = new Date();

    for (let i = 83; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);

      const weekIndex = Math.floor(i / 7);
      if (!weeksArray[weekIndex]) {
        weeksArray[weekIndex] = [];
      }
      weeksArray[weekIndex].push(date);
    }

    return weeksArray;
  }, []);

  const getIntensity = (date: Date): number => {
    const dateStr = date.toDateString();
    const count = productivityRecords.filter((r) => new Date(r.date).toDateString() === dateStr).length;
    if (count === 0) return 0;
    if (count === 1) return 1;
    if (count <= 2) return 2;
    return 3;
  };

  const intensityColors = {
    0: "bg-muted/30",
    1: "bg-green-400/40",
    2: "bg-green-500/60",
    3: "bg-green-600/80",
  };

  return (
    <Card className="p-6 shadow-sm">
      <div className="mb-4">
        <h3 className="text-lg font-semibold mb-2">Calendário de Frequência</h3>
        <p className="text-sm text-muted-foreground">
          Sequência atual: <span className="font-bold text-primary">{studyStreak.currentStreak} dias</span> | Maior sequência: <span className="font-bold text-accent">{studyStreak.longestStreak} dias</span>
        </p>
      </div>

      {/* Legenda */}
      <div className="flex items-center gap-4 mb-6 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded bg-muted/30" />
          <span>Sem estudo</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded bg-green-400/40" />
          <span>1 sessão</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded bg-green-500/60" />
          <span>2 sessões</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded bg-green-600/80" />
          <span>3+ sessões</span>
        </div>
      </div>

      {/* Calendário */}
      <div className="space-y-2 overflow-x-auto">
        {weeks.map((week, weekIndex) => (
          <div key={weekIndex} className="flex gap-1">
            {week.map((date, dayIndex) => {
              const intensity = getIntensity(date) as keyof typeof intensityColors;
              const isToday = date.toDateString() === new Date().toDateString();

              return (
                <div
                  key={dayIndex}
                  className={`w-3 h-3 rounded transition-all duration-200 ${
                    intensityColors[intensity]
                  } ${isToday ? "ring-2 ring-primary" : ""}`}
                  title={`${date.toLocaleDateString("pt-BR")}: ${
                    intensity === 0 ? "Sem estudo" : `${intensity} sessão(ões)`
                  }`}
                />
              );
            })}
          </div>
        ))}
      </div>

      {/* Info */}
      <div className="mt-6 p-3 bg-blue-500/10 border border-blue-500/20 rounded text-sm text-muted-foreground">
        <p>
          <span className="font-semibold text-blue-600 dark:text-blue-400">💡 Dica:</span> Mantenha a
          consistência! Quanto mais dias seguidos de estudo, mais perto você fica de desbloquear a medalha de "Consistência".
        </p>
      </div>
    </Card>
  );
}
