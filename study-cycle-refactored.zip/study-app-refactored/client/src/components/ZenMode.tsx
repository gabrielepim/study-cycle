import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

interface ZenModeProps {
  isActive: boolean;
  onClose: () => void;
  timeRemaining: string;
  subject: string;
  focus: string;
}

export default function ZenMode({ isActive, onClose, timeRemaining, subject, focus }: ZenModeProps) {
  const [displayTime, setDisplayTime] = useState(timeRemaining);

  useEffect(() => {
    setDisplayTime(timeRemaining);
  }, [timeRemaining]);

  if (!isActive) return null;

  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col items-center justify-center overflow-hidden">
      {/* Botão de Fechar */}
      <button
        onClick={onClose}
        className="absolute top-6 right-6 p-3 hover:bg-muted rounded-lg transition-colors duration-200 group"
        title="Sair do Modo Zen (ESC)"
      >
        <X className="w-6 h-6 text-muted-foreground group-hover:text-foreground transition-colors" />
      </button>

      {/* Conteúdo Principal */}
      <div className="flex flex-col items-center justify-center h-full gap-8">
        {/* Matéria e Foco */}
        <div className="text-center space-y-2">
          <p className="text-muted-foreground text-lg">Você está estudando</p>
          <h1 className="text-5xl md:text-6xl font-bold text-primary mb-4">{subject}</h1>
          <div className="flex items-center justify-center gap-4">
            <span className="px-4 py-2 bg-accent/20 rounded-full text-accent font-semibold">
              {focus}
            </span>
          </div>
        </div>

        {/* Cronômetro Grande */}
        <div className="flex flex-col items-center gap-6">
          <div className="text-9xl md:text-[12rem] font-mono font-bold text-primary tracking-tighter">
            {displayTime}
          </div>
          <p className="text-xl text-muted-foreground">Tempo Restante</p>
        </div>

        {/* Dica de Saída */}
        <div className="text-center text-sm text-muted-foreground">
          <p>Pressione <span className="font-semibold">ESC</span> ou clique no X para sair do Modo Zen</p>
        </div>
      </div>

      {/* Fundo com Gradiente Suave */}
      <div className="absolute inset-0 -z-10 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 pointer-events-none" />
    </div>
  );
}
