/**
 * Tipos e interfaces para o Study Cycle App
 * Design: Minimalismo Funcional com Acentos Dinâmicos
 */

export interface StudySession {
  id: number;
  name: string;
  subject: string;
  duration: number; // em minutos
  order: number;
}

export interface CycleProgress {
  currentSessionId: number;
  completedSessions: number[];
  totalSessions: number;
  cycleStartDate: string;
}

export interface ProductivityRecord {
  id: string;
  sessionId: number;
  sessionName: string;
  date: string;
  questionsAttempted: number;
  questionsCorrect: number;
  successRate: number; // percentual
  duration: number; // em minutos
  focus?: "Teoria" | "Questões" | "Revisão"; // Foco da sessão
}

export interface ErrorEntry {
  id: string;
  subject: string;
  description: string;
  errorType: "Lei Seca" | "Atenção" | "Teoria";
  category: "Legislação" | "Geral"; // Categorização automática
  date: string;
  sessionId?: number;
  lastPage?: string; // Última página ou aula onde parou
}

export interface ExamQuestion {
  id: string;
  organ?: string; // Órgão (ex: Câmara dos Deputados)
  banca?: string; // Banca (ex: CESPE)
  year?: number; // Ano
  subject: string; // Matéria
  enunciation: string; // Enunciado da questão
  alternatives: {
    a: string;
    b: string;
    c: string;
    d: string;
    e: string;
  };
  correctAnswer: "a" | "b" | "c" | "d" | "e"; // Resposta correta
  userAnswer?: "a" | "b" | "c" | "d" | "e"; // Resposta do usuário
  questionType: "Múltipla Escolha" | "Verdadeiro/Falso" | "Discursiva";
  errorTags: ("Lei Seca" | "Atenção" | "Teoria" | "Pegadinha da Banca")[]; // Tags de erro
  comments: string; // Comentários sobre a questão
  date: string;
  isRevealed: boolean; // Se a resposta correta foi revelada
}

export interface EditorialTopic {
  id: string;
  subject: string;
  topic: string;
  subtopics: Subtopic[];
  lastReviewDate?: string; // Data da última revisão
  freshness: "green" | "yellow" | "red"; // Verde (<15 dias), Amarelo (15-30 dias), Vermelho (>30 dias)
}

export interface Subtopic {
  id: string;
  name: string;
  theory: boolean;
  review: boolean;
  questions: boolean;
  reviewDate?: string; // Data da última revisão
}

export interface DashboardMetrics {
  totalAccuracyRate: number;
  totalNetHours: number;
  accuracyBySubject: Record<string, number>;
  errorDistribution: Record<string, number>;
  legislationErrors: number;
  generalErrors: number;
}

export interface WeekendBlock {
  id: string;
  date: string;
  type: "Discursiva" | "Revisão Geral";
  duration: number; // em minutos
  completed: boolean;
}

export interface Medal {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlockedDate?: string;
  progress?: number; // 0-100
}

export interface StudyFocus {
  date: string;
  focus: "Teoria" | "Questões" | "Revisão";
  sessionId: number;
}

export interface StudyStreak {
  currentStreak: number;
  longestStreak: number;
  lastStudyDate?: string;
}

export interface Argument {
  id: string;
  subject: "Relações Públicas" | "Legislação" | "Geral";
  title: string;
  content: string;
  tags: string[];
  createdDate: string;
}

export interface StudyCalendarDay {
  date: string; // YYYY-MM-DD
  studied: boolean;
  duration: number; // em minutos
  sessionType: "Ciclo" | "Discursiva" | "Revisão Geral"; // Tipo de sessão
}

export interface BackupData {
  version: string;
  exportDate: string;
  cycleProgress: CycleProgress;
  productivityRecords: ProductivityRecord[];
  errorEntries: ErrorEntry[];
  editorialTopics: EditorialTopic[];
  weekendBlocks: WeekendBlock[];
  unlockedMedals: Medal[];
  studyStreak: StudyStreak;
  arguments: Argument[];
  examQuestions: ExamQuestion[];
}

export const TIMER_DURATION = 7200; // 2 horas em segundos

export const STUDY_SESSIONS: StudySession[] = [
  { id: 1, name: "S1", subject: "Relações Públicas", duration: 120, order: 1 },
  { id: 2, name: "S2", subject: "Português", duration: 120, order: 2 },
  { id: 3, name: "S3", subject: "Regimento Interno CD", duration: 120, order: 3 },
  { id: 4, name: "S4", subject: "Dir. Administrativo", duration: 120, order: 4 },
  { id: 5, name: "S5", subject: "Raciocínio Lógico", duration: 120, order: 5 },
  { id: 6, name: "S6", subject: "Dir. Constitucional", duration: 120, order: 6 },
  { id: 7, name: "S7", subject: "Relações Públicas", duration: 120, order: 7 },
  { id: 8, name: "S8", subject: "Informática", duration: 120, order: 8 },
  { id: 9, name: "S9", subject: "Inglês", duration: 120, order: 9 },
];

export const LEGISLATION_SUBJECTS = ["Regimento Interno CD", "Dir. Administrativo", "Dir. Constitucional"];

export const STORAGE_KEYS = {
  CYCLE_PROGRESS: "study-cycle:progress",
  PRODUCTIVITY_RECORDS: "study-cycle:productivity",
  ERROR_ENTRIES: "study-cycle:errors",
  EDITORIAL_TOPICS: "study-cycle:editorial",
  WEEKEND_BLOCKS: "study-cycle:weekend",
  THEME: "study-cycle:theme",
  MEDALS: "study-cycle:medals",
  STUDY_FOCUS: "study-cycle:focus",
  STUDY_STREAK: "study-cycle:streak",
  ARGUMENTS: "study-cycle:arguments",
  ZEN_MODE: "study-cycle:zen-mode",
  EXAM_QUESTIONS: "study-cycle:exam-questions",
  STUDY_CALENDAR: "study-cycle:calendar",
};

export const MEDAL_DEFINITIONS: Medal[] = [
  {
    id: "seven-days",
    name: "Consistência",
    description: "7 dias de estudo seguidos",
    icon: "🔥",
  },
  {
    id: "hundred-questions",
    name: "Centésimo",
    description: "100 questões feitas",
    icon: "💯",
  },
  {
    id: "legislation-master",
    name: "Mestre da Legislação",
    description: "90% de acurácia em Legislação",
    icon: "⚖️",
  },
  {
    id: "perfect-session",
    name: "Sessão Perfeita",
    description: "100% de acurácia em uma sessão",
    icon: "✨",
  },
  {
    id: "night-owl",
    name: "Coruja Noturna",
    description: "10 sessões completadas",
    icon: "🦉",
  },
];
