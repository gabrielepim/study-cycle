import { ProductivityRecord, ErrorEntry, EditorialTopic } from "@/types";

export function useExportCSV() {
  const exportProductivityToCSV = (records: ProductivityRecord[], filename: string = "produtividade.csv") => {
    if (records.length === 0) {
      alert("Nenhum registro de produtividade para exportar");
      return;
    }

    const headers = [
      "Data",
      "Sessão",
      "Matéria",
      "Questões Feitas",
      "Acertos",
      "Taxa de Acerto (%)",
      "Duração (min)",
    ];

    const rows = records.map((r) => [
      new Date(r.date).toLocaleDateString("pt-BR"),
      r.sessionName,
      "", // Matéria será preenchida se disponível
      r.questionsAttempted,
      r.questionsCorrect,
      r.successRate,
      r.duration,
    ]);

    const csv = [headers, ...rows].map((row) => row.map((cell: any) => `"${cell}"`).join(",")).join("\n");

    downloadCSV(csv, filename);
  };

  const exportErrorsToCSV = (errors: ErrorEntry[], filename: string = "erros.csv") => {
    if (errors.length === 0) {
      alert("Nenhum erro para exportar");
      return;
    }

    const headers = [
      "Data",
      "Matéria",
      "Tipo de Erro",
      "Categoria",
      "Descrição",
      "Última Parada",
    ];

    const rows = errors.map((e) => [
      new Date(e.date).toLocaleDateString("pt-BR"),
      e.subject,
      e.errorType,
      e.category,
      e.description,
      e.lastPage || "-",
    ]);

    const csv = [headers, ...rows].map((row) => row.map((cell: any) => `"${cell}"`).join(",")).join("\n");

    downloadCSV(csv, filename);
  };

  const exportEditorialToCSV = (topics: EditorialTopic[], filename: string = "edital.csv") => {
    if (topics.length === 0) {
      alert("Nenhum tópico para exportar");
      return;
    }

    const headers = [
      "Matéria",
      "Tópico Principal",
      "Subtópico",
      "Teoria",
      "Revisão",
      "Questões",
      "Última Revisão",
      "Freshness",
    ];

    const rows: any[] = [];
    topics.forEach((topic) => {
      topic.subtopics.forEach((subtopic) => {
        rows.push([
          topic.subject,
          topic.topic,
          subtopic.name,
          subtopic.theory ? "✓" : "✗",
          subtopic.review ? "✓" : "✗",
          subtopic.questions ? "✓" : "✗",
          topic.lastReviewDate
            ? new Date(topic.lastReviewDate).toLocaleDateString("pt-BR")
            : "-",
          topic.freshness,
        ]);
      });
    });

    const csv = [headers, ...rows].map((row) => row.map((cell: any) => `"${cell}"`).join(",")).join("\n");

    downloadCSV(csv, filename);
  };

  const exportCompleteHistoryToCSV = (
    productivity: ProductivityRecord[],
    errors: ErrorEntry[],
    editorial: EditorialTopic[],
    filename: string = "historico_completo.csv"
  ) => {
    let csv = "";

    // Seção de Produtividade
    csv += "=== HISTÓRICO DE PRODUTIVIDADE ===\n";
    csv += "Data,Sessão,Questões Feitas,Acertos,Taxa de Acerto (%),Duração (min)\n";
    productivity.forEach((r) => {
      csv += `${new Date(r.date).toLocaleDateString("pt-BR")},${r.sessionName},${r.questionsAttempted},${r.questionsCorrect},${r.successRate},${r.duration}\n`;
    });

    csv += "\n=== CADERNO DE ERROS ===\n";
    csv += "Data,Matéria,Tipo de Erro,Categoria,Descrição,Última Parada\n";
    errors.forEach((e) => {
      csv += `${new Date(e.date).toLocaleDateString("pt-BR")},${e.subject},${e.errorType},${e.category},"${e.description}",${e.lastPage || "-"}\n`;
    });

    csv += "\n=== EDITAL VERTICALIZADO ===\n";
    csv += "Matéria,Tópico Principal,Subtópico,Teoria,Revisão,Questões,Última Revisão,Freshness\n";
    editorial.forEach((topic) => {
      topic.subtopics.forEach((subtopic) => {
        csv += `${topic.subject},${topic.topic},${subtopic.name},${subtopic.theory ? "✓" : "✗"},${subtopic.review ? "✓" : "✗"},${subtopic.questions ? "✓" : "✗"},${
          topic.lastReviewDate ? new Date(topic.lastReviewDate).toLocaleDateString("pt-BR") : "-"
        },${topic.freshness}\n`;
      });
    });

    downloadCSV(csv, filename);
  };

  const downloadCSV = (csv: string, filename: string) => {
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);

    link.setAttribute("href", url);
    link.setAttribute("download", filename);
    link.style.visibility = "hidden";

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return {
    exportProductivityToCSV,
    exportErrorsToCSV,
    exportEditorialToCSV,
    exportCompleteHistoryToCSV,
  };
}
