import { useState, useEffect, useCallback, useRef } from 'react';

import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

interface TimerState {
  timeLeft: number;
  isRunning: boolean;
  totalDuration: number;
  lastSavedTime: number;
  sessionId: number;
  sessionName: string;
  startedAt: number;
}

const TIMER_STORAGE_KEY = 'study-cycle-timer-state';
const SAVE_INTERVAL = 10000; // Salvar a cada 10 segundos

export function useTimerPersistence(initialDuration: number, sessionId: number, sessionName: string) {
  const [timerState, setTimerState] = useState<TimerState>(() => {
    const saved = localStorage.getItem(TIMER_STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as TimerState;
        if (parsed.isRunning && parsed.lastSavedTime > 0) {
          const elapsedSinceLastSave = (Date.now() - parsed.lastSavedTime) / 1000;
          const newTimeLeft = Math.max(0, parsed.timeLeft - elapsedSinceLastSave);
          return {
            ...parsed,
            timeLeft: newTimeLeft,
            lastSavedTime: Date.now(),
          };
        }
        return parsed;
      } catch {
        return {
          timeLeft: initialDuration,
          isRunning: false,
          totalDuration: initialDuration,
          lastSavedTime: Date.now(),
          sessionId,
          sessionName,
          startedAt: Date.now(),
        };
      }
    }

    return {
      timeLeft: initialDuration,
      isRunning: false,
      totalDuration: initialDuration,
      lastSavedTime: Date.now(),
      sessionId,
      sessionName,
      startedAt: Date.now(),
    };
  });

  const productivityMutation = trpc.productivity.addRecord.useMutation();
  const saveTimeoutRef = useRef<NodeJS.Timeout | undefined>(undefined);

  // Salvar estado a cada 10 segundos
  useEffect(() => {
    const saveInterval = setInterval(() => {
      if (timerState.isRunning) {
        const stateToSave = {
          ...timerState,
          lastSavedTime: Date.now(),
        };
        localStorage.setItem(TIMER_STORAGE_KEY, JSON.stringify(stateToSave));
      }
    }, SAVE_INTERVAL);

    return () => clearInterval(saveInterval);
  }, [timerState]);

  // Atualizar timer a cada segundo
  useEffect(() => {
    let interval: NodeJS.Timeout | undefined;

    if (timerState.isRunning && timerState.timeLeft > 0) {
      interval = setInterval(() => {
        setTimerState((prev) => ({
          ...prev,
          timeLeft: Math.max(0, prev.timeLeft - 1),
        }));
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [timerState.isRunning, timerState.timeLeft]);

  const getStudyQuality = useCallback(() => {
    const elapsedSeconds = timerState.totalDuration - timerState.timeLeft;
    const elapsedHours = elapsedSeconds / 3600;

    if (elapsedHours < 1) {
      return { status: 'red', label: 'Curto', message: 'Sugerir repetição amanhã' };
    } else if (elapsedHours < 2) {
      return { status: 'yellow', label: 'Médio', message: 'Bom progresso' };
    } else if (elapsedHours >= 2) {
      return { status: 'green', label: elapsedHours > 2 ? 'Excelente' : 'Perfeito', message: elapsedHours > 2 ? 'Medalha de Excelência!' : 'Meta atingida!' };
    }
    return { status: 'yellow', label: 'Médio', message: 'Bom progresso' };
  }, [timerState.totalDuration, timerState.timeLeft]);

  const start = useCallback(() => {
    setTimerState((prev) => ({
      ...prev,
      isRunning: true,
      lastSavedTime: Date.now(),
    }));
  }, []);

  const pause = useCallback(() => {
    setTimerState((prev) => ({
      ...prev,
      isRunning: false,
      lastSavedTime: Date.now(),
    }));
  }, []);

  const stop = useCallback(async () => {
    const elapsedSeconds = timerState.totalDuration - timerState.timeLeft;
    const quality = getStudyQuality();

    // POST ao banco de dados
    try {
      await productivityMutation.mutateAsync({
        id: `prod-${Date.now()}`,
        sessionId: timerState.sessionId,
        sessionName: timerState.sessionName,
        questionsAttempted: 0,
        questionsCorrect: 0,
        successRate: '0',
        duration: Math.round(elapsedSeconds / 60),
        focus: 'Teoria' as const,
      });

      toast.success(`Sessão finalizada! Status: ${quality.label}`, {
        description: quality.message,
        duration: 5000,
      });
    } catch (error) {
      toast.error('Erro ao salvar sessão no banco de dados');
      console.error(error);
    }

    setTimerState((prev) => ({
      ...prev,
      isRunning: false,
      timeLeft: 0,
      lastSavedTime: Date.now(),
    }));
    localStorage.removeItem(TIMER_STORAGE_KEY);
  }, [timerState, getStudyQuality, productivityMutation]);

  const reset = useCallback(() => {
    setTimerState((prev) => ({
      ...prev,
      isRunning: false,
      timeLeft: prev.totalDuration,
      lastSavedTime: Date.now(),
      startedAt: Date.now(),
    }));
    localStorage.removeItem(TIMER_STORAGE_KEY);
  }, []);

  const addTime = useCallback((minutes: number) => {
    setTimerState((prev) => ({
      ...prev,
      timeLeft: prev.timeLeft + minutes * 60,
      totalDuration: prev.totalDuration + minutes * 60,
    }));
  }, []);

  const subtractTime = useCallback((minutes: number) => {
    setTimerState((prev) => ({
      ...prev,
      timeLeft: Math.max(0, prev.timeLeft - minutes * 60),
      totalDuration: Math.max(0, prev.totalDuration - minutes * 60),
    }));
  }, []);

  return {
    timeLeft: timerState.timeLeft,
    isRunning: timerState.isRunning,
    totalDuration: timerState.totalDuration,
    start,
    pause,
    stop,
    reset,
    addTime,
    subtractTime,
    getStudyQuality,
    isSaving: productivityMutation.isPending,
  };
}
