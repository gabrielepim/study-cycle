import { useStudyCycle } from "@/contexts/StudyCycleContext";
import { BackupData } from "@/types";

export function useBackup() {
  const {
    cycleProgress,
    productivityRecords,
    errorEntries,
    editorialTopics,
    weekendBlocks,
    unlockedMedals,
    studyStreak,
    arguments: savedArguments,
  } = useStudyCycle();

  const exportAsJSON = () => {
    const backupData: BackupData = {
      version: "1.0.0",
      exportDate: new Date().toISOString(),
      cycleProgress,
      productivityRecords,
      errorEntries,
      editorialTopics,
      weekendBlocks,
      unlockedMedals,
      studyStreak,
      arguments: savedArguments,
      examQuestions: [],
    };

    const dataStr = JSON.stringify(backupData, null, 2);
    const dataBlob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `study-cycle-backup-${new Date().toISOString().split("T")[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const exportAsCSV = () => {
    // Exportar Produtividade
    const productivityCSV = [
      ["Data", "Matéria", "Questões Feitas", "Acertos", "Taxa de Acerto (%)", "Duração (min)", "Foco"].join(","),
      ...productivityRecords.map((r) =>
        [
          new Date(r.date).toLocaleDateString("pt-BR"),
          r.sessionName,
          r.questionsAttempted,
          r.questionsCorrect,
          r.successRate,
          r.duration,
          r.focus || "N/A",
        ].join(",")
      ),
    ].join("\n");

    // Exportar Erros
    const errorsCSV = [
      ["Data", "Matéria", "Descrição", "Tipo de Erro", "Categoria", "Última Parada"].join(","),
      ...errorEntries.map((e) =>
        [
          new Date(e.date).toLocaleDateString("pt-BR"),
          e.subject,
          `"${e.description}"`,
          e.errorType,
          e.category,
          e.lastPage || "N/A",
        ].join(",")
      ),
    ].join("\n");

    // Criar arquivo ZIP com múltiplos CSVs
    const combinedCSV = `PRODUTIVIDADE\n${productivityCSV}\n\n\nERROS\n${errorsCSV}`;

    const dataBlob = new Blob([combinedCSV], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `study-cycle-export-${new Date().toISOString().split("T")[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const exportAsText = () => {
    let textContent = "=== ESTUDO CYCLE - RELATÓRIO COMPLETO ===\n\n";
    textContent += `Data de Exportação: ${new Date().toLocaleDateString("pt-BR")} às ${new Date().toLocaleTimeString("pt-BR")}\n\n`;

    // Resumo
    textContent += "=== RESUMO ===\n";
    textContent += `Total de Sessões Completadas: ${productivityRecords.length}\n`;
    textContent += `Taxa de Acerto Média: ${productivityRecords.length > 0 ? (productivityRecords.reduce((sum, r) => sum + r.successRate, 0) / productivityRecords.length).toFixed(2) : 0}%\n`;
    textContent += `Total de Erros Registrados: ${errorEntries.length}\n`;
    textContent += `Sequência Atual: ${studyStreak.currentStreak} dias\n`;
    textContent += `Maior Sequência: ${studyStreak.longestStreak} dias\n\n`;

    // Produtividade
    textContent += "=== HISTÓRICO DE PRODUTIVIDADE ===\n";
    productivityRecords.forEach((r) => {
      textContent += `\n[${new Date(r.date).toLocaleDateString("pt-BR")}] ${r.sessionName}\n`;
      textContent += `  Questões: ${r.questionsAttempted} | Acertos: ${r.questionsCorrect} | Taxa: ${r.successRate}%\n`;
      textContent += `  Duração: ${r.duration} minutos | Foco: ${r.focus || "N/A"}\n`;
    });

    // Erros
    textContent += "\n\n=== HISTÓRICO DE ERROS ===\n";
    errorEntries.forEach((e) => {
      textContent += `\n[${new Date(e.date).toLocaleDateString("pt-BR")}] ${e.subject}\n`;
      textContent += `  Descrição: ${e.description}\n`;
      textContent += `  Tipo: ${e.errorType} | Categoria: ${e.category}\n`;
      if (e.lastPage) textContent += `  Última Parada: ${e.lastPage}\n`;
    });

    const dataBlob = new Blob([textContent], { type: "text/plain;charset=utf-8;" });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `study-cycle-report-${new Date().toISOString().split("T")[0]}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return {
    exportAsJSON,
    exportAsCSV,
    exportAsText,
  };
}
