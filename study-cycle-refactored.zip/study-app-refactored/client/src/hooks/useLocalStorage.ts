import { useState, useEffect, useCallback } from "react";

/**
 * Hook customizado para gerenciar dados no LocalStorage
 * Sincroniza estado com localStorage automaticamente
 */
export function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T | ((val: T) => T)) => void] {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(`Erro ao ler localStorage[${key}]:`, error);
      return initialValue;
    }
  });

  const setValue = useCallback(
    (value: T | ((val: T) => T)) => {
      try {
        const valueToStore = value instanceof Function ? value(storedValue) : value;
        setStoredValue(valueToStore);
        window.localStorage.setItem(key, JSON.stringify(valueToStore));
      } catch (error) {
        console.error(`Erro ao escrever localStorage[${key}]:`, error);
      }
    },
    [key, storedValue]
  );

  return [storedValue, setValue];
}

/**
 * Hook para sincronizar múltiplas chaves do localStorage
 */
export function useLocalStorageSync<T extends Record<string, any>>(
  keys: Record<keyof T, string>,
  initialValues: T
): [T, (updates: Partial<T>) => void] {
  const [data, setData] = useState<T>(() => {
    const result = { ...initialValues };
    try {
      for (const [key, storageKey] of Object.entries(keys)) {
        const item = window.localStorage.getItem(storageKey as string);
        if (item) {
          result[key as keyof T] = JSON.parse(item);
        }
      }
    } catch (error) {
      console.error("Erro ao sincronizar localStorage:", error);
    }
    return result;
  });

  const updateData = useCallback(
    (updates: Partial<T>) => {
      setData((prev) => {
        const updated = { ...prev, ...updates };
        try {
          for (const [key, value] of Object.entries(updates)) {
            const storageKey = keys[key as keyof T];
            if (storageKey) {
              window.localStorage.setItem(storageKey, JSON.stringify(value));
            }
          }
        } catch (error) {
          console.error("Erro ao atualizar localStorage:", error);
        }
        return updated;
      });
    },
    [keys]
  );

  return [data, updateData];
}
