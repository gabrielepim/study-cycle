import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';
import { useCallback } from 'react';

export function useCRUDOperations() {
  const errorsMutation = trpc.errors.deleteEntry.useMutation();
  const editorialMutation = trpc.editorial.deleteTopic.useMutation();
  const argumentsMutation = trpc.arguments.delete.useMutation();
  const examQuestionsMutation = trpc.examQuestions.delete.useMutation();

  const deleteError = useCallback(
    async (id: string, onSuccess?: () => void) => {
      try {
        await errorsMutation.mutateAsync({ id });
        toast.success('Erro removido com sucesso!', { duration: 3000 });
        onSuccess?.();
      } catch (error) {
        toast.error('Erro ao remover entrada do banco de dados');
        console.error(error);
      }
    },
    [errorsMutation]
  );

  const deleteEditorialTopic = useCallback(
    async (id: string, onSuccess?: () => void) => {
      try {
        await editorialMutation.mutateAsync({ id });
        toast.success('Tópico removido com sucesso!', { duration: 3000 });
        onSuccess?.();
      } catch (error) {
        toast.error('Erro ao remover tópico do banco de dados');
        console.error(error);
      }
    },
    [editorialMutation]
  );

  const deleteArgument = useCallback(
    async (id: string, onSuccess?: () => void) => {
      try {
        await argumentsMutation.mutateAsync({ id });
        toast.success('Argumento removido com sucesso!', { duration: 3000 });
        onSuccess?.();
      } catch (error) {
        toast.error('Erro ao remover argumento do banco de dados');
        console.error(error);
      }
    },
    [argumentsMutation]
  );

  const deleteExamQuestion = useCallback(
    async (id: string, onSuccess?: () => void) => {
      try {
        await examQuestionsMutation.mutateAsync({ id });
        toast.success('Questão removida com sucesso!', { duration: 3000 });
        onSuccess?.();
      } catch (error) {
        toast.error('Erro ao remover questão do banco de dados');
        console.error(error);
      }
    },
    [examQuestionsMutation]
  );

  return {
    deleteError,
    deleteEditorialTopic,
    deleteArgument,
    deleteExamQuestion,
    isLoading:
      errorsMutation.isPending ||
      editorialMutation.isPending ||
      argumentsMutation.isPending ||
      examQuestionsMutation.isPending,
  };
}
