import { router, protectedProcedure } from "../_core/trpc";
import { z } from "zod";
import { getDb } from "../db";
import { srsErrors, gamificationStats } from "../../drizzle/schema";
import { eq, and, lte, desc, sql } from "drizzle-orm";
import { invokeLLM } from "../_core/llm";
import { nanoid } from "nanoid";

const SRS_QUALITY = {
  DIFFICULT: 1,
  MEDIUM: 3,
  EASY: 5,
};

// Algoritmo SM-2 para Spaced Repetition
function calculateNextReview(
  quality: number,
  interval: number,
  easeFactor: number,
  repetitions: number
) {
  let newEaseFactor = easeFactor + 0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02);
  newEaseFactor = Math.max(1.3, newEaseFactor);

  let newInterval: number;
  let newRepetitions = repetitions + 1;

  if (quality < 3) {
    newInterval = 1;
    newRepetitions = 1;
  } else {
    if (repetitions === 0) {
      newInterval = 1;
    } else if (repetitions === 1) {
      newInterval = 3;
    } else {
      newInterval = Math.round(interval * newEaseFactor);
    }
  }

  const nextReviewDate = new Date();
  nextReviewDate.setDate(nextReviewDate.getDate() + newInterval);

  return {
    interval: newInterval,
    easeFactor: newEaseFactor,
    repetitions: newRepetitions,
    nextReviewDate,
  };
}

export const srsRouter = router({
  // Gerar questão a partir de um erro usando IA
  generateFromError: protectedProcedure
    .input(z.object({ errorId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const error = await db
        .select()
        .from(srsErrors)
        .where(and(eq(srsErrors.id, input.errorId), eq(srsErrors.userId, ctx.user!.id)))
        .limit(1);

      if (!error.length) throw new Error("Error not found");

      const errorData = error[0];

      // Chamar LLM para gerar questão
      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content:
              "Você é um gerador de questões de múltipla escolha. Crie uma questão baseada no erro fornecido. Retorne um JSON com: question, options (objeto com a, b, c, d, e), answer (letra), explanation.",
          },
          {
            role: "user",
            content: `Erro: ${errorData.subject}\nDescrição: ${errorData.description}\n\nGere uma questão de múltipla escolha sobre este erro.`,
          },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "generated_question",
            strict: true,
            schema: {
              type: "object",
              properties: {
                question: { type: "string" },
                options: {
                  type: "object",
                  properties: {
                    a: { type: "string" },
                    b: { type: "string" },
                    c: { type: "string" },
                    d: { type: "string" },
                    e: { type: "string" },
                  },
                  required: ["a", "b", "c", "d", "e"],
                },
                answer: { type: "string", enum: ["a", "b", "c", "d", "e"] },
                explanation: { type: "string" },
              },
              required: ["question", "options", "answer", "explanation"],
              additionalProperties: false,
            },
          },
        },
      });

      const content = response.choices[0]?.message.content;
      if (!content || typeof content !== "string") throw new Error("Failed to generate question");

      const generated = JSON.parse(content);

      // Atualizar erro com questão gerada
      await db
        .update(srsErrors)
        .set({
          question: generated.question,
          options: generated.options,
          answer: generated.answer,
          explanation: generated.explanation,
          generated: true,
          updatedAt: new Date(),
        })
        .where(eq(srsErrors.id, input.errorId));

      return generated;
    }),

  // Registrar revisão e atualizar SRS
  review: protectedProcedure
    .input(
      z.object({
        errorId: z.string(),
        quality: z.enum(["1", "3", "5"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const error = await db
        .select()
        .from(srsErrors)
        .where(and(eq(srsErrors.id, input.errorId), eq(srsErrors.userId, ctx.user!.id)))
        .limit(1);

      if (!error.length) throw new Error("Error not found");

      const errorData = error[0];
      const qualityNum = parseInt(input.quality);

      const srsUpdate = calculateNextReview(
        qualityNum,
        errorData.interval,
        errorData.easeFactor,
        errorData.repetitions
      );

      // Atualizar SRS
      await db
        .update(srsErrors)
        .set({
          interval: srsUpdate.interval,
          easeFactor: srsUpdate.easeFactor,
          repetitions: srsUpdate.repetitions,
          nextReviewDate: srsUpdate.nextReviewDate,
          lastReviewDate: new Date(),
          timesSeen: errorData.timesSeen + 1,
          updatedAt: new Date(),
        })
        .where(eq(srsErrors.id, input.errorId));

      // Adicionar XP
      const xpGain = errorData.xpReward * (qualityNum === 5 ? 1.5 : qualityNum === 3 ? 1 : 0.5);

      const gamificationRecord = await db
        .select()
        .from(gamificationStats)
        .where(eq(gamificationStats.userId, ctx.user!.id))
        .limit(1);

      if (gamificationRecord.length) {
        const newXp = gamificationRecord[0].xp + Math.round(xpGain);
        const newLevel = Math.floor(newXp / 100) + 1;

        await db
          .update(gamificationStats)
          .set({
            xp: newXp,
            level: newLevel,
            updatedAt: new Date(),
          })
          .where(eq(gamificationStats.userId, ctx.user!.id));
      }

      return { success: true, xpGain: Math.round(xpGain) };
    }),

  // Obter fila inteligente de questões para revisar
  getQueue: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const now = new Date();

    // Buscar erros vencidos ou próximos de vencer
    const overdue = await db
      .select()
      .from(srsErrors)
      .where(
        and(
          eq(srsErrors.userId, ctx.user!.id),
          lte(srsErrors.nextReviewDate, new Date(now.getTime() + 24 * 60 * 60 * 1000))
        )
      )
      .orderBy(
        desc(
          sql`CASE 
            WHEN ${srsErrors.nextReviewDate} <= ${now} THEN 0
            WHEN ${srsErrors.difficulty} > 0.7 THEN 1
            ELSE 2
          END`
        ),
        desc(srsErrors.timesSeen)
      )
      .limit(10);

    // Calcular score dinâmico para cada item
    const queue = overdue.map((item) => {
      const daysOverdue = Math.max(
        0,
        (now.getTime() - item.nextReviewDate.getTime()) / (1000 * 60 * 60 * 24)
      );
      const score =
        daysOverdue * 10 + // Penalidade por vencimento
        item.difficulty * 5 + // Dificuldade
        item.timesSeen * 0.5 + // Número de revisões
        Math.random() * 2; // Leve aleatoriedade

      return { ...item, score };
    });

    return queue.sort((a, b) => b.score - a.score);
  }),

  // Criar novo erro (para ser transformado em questão)
  createError: protectedProcedure
    .input(
      z.object({
        subject: z.string(),
        description: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const newError = {
        id: nanoid(),
        userId: ctx.user!.id,
        subject: input.subject,
        description: input.description,
        interval: 1,
        easeFactor: 2.5,
        repetitions: 0,
        nextReviewDate: new Date(),
        lastReviewDate: new Date(),
        difficulty: 0.5,
        timesSeen: 0,
        xpReward: 10,
        generated: false,
        question: null,
        options: { a: "", b: "", c: "", d: "", e: "" },
        answer: null,
        explanation: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      await db.insert(srsErrors).values(newError);

      return newError;
    }),

  // Obter estatísticas do usuário
  getStats: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const stats = await db
      .select()
      .from(gamificationStats)
      .where(eq(gamificationStats.userId, ctx.user!.id))
      .limit(1);

    if (!stats.length) {
      // Criar stats padrão
      const newStats = {
        id: nanoid(),
        userId: ctx.user!.id,
        xp: 0,
        level: 1,
        streak: 0,
        longestStreak: 0,
        lastStudyDate: new Date(),
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      await db.insert(gamificationStats).values(newStats);
      return newStats;
    }

    return stats[0];
  }),
});
