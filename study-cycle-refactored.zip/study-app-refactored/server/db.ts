import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// TODO: add feature queries here as your schema grows.

// Study Cycle Query Helpers
import {
  cycleProgress,
  productivityRecords,
  errorEntries,
  editorialTopics,
  weekendBlocks,
  argumentsTable,
  examQuestions,
  studyCalendar,
  type InsertCycleProgress,
  type InsertProductivityRecord,
  type InsertErrorEntry,
  type InsertEditorialTopic,
  type InsertWeekendBlock,
  type InsertArgument,
  type InsertExamQuestion,
  type InsertStudyCalendarDay,
} from "../drizzle/schema";

// Cycle Progress
export async function getCycleProgress(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(cycleProgress).where(eq(cycleProgress.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function upsertCycleProgress(userId: number, data: Partial<InsertCycleProgress>) {
  const db = await getDb();
  if (!db) return null;
  const existing = await getCycleProgress(userId);
  if (existing) {
    await db.update(cycleProgress).set(data).where(eq(cycleProgress.userId, userId));
  } else {
    await db.insert(cycleProgress).values({ userId, ...data } as InsertCycleProgress);
  }
  return getCycleProgress(userId);
}

// Productivity Records
export async function getProductivityRecords(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(productivityRecords).where(eq(productivityRecords.userId, userId));
}

export async function addProductivityRecord(userId: number, data: Omit<InsertProductivityRecord, 'userId'>) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(productivityRecords).values({ userId, ...data } as InsertProductivityRecord);
  return data;
}

// Error Entries
export async function getErrorEntries(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(errorEntries).where(eq(errorEntries.userId, userId));
}

export async function addErrorEntry(userId: number, data: Omit<InsertErrorEntry, 'userId'>) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(errorEntries).values({ userId, ...data } as InsertErrorEntry);
  return data;
}

export async function deleteErrorEntry(id: string) {
  const db = await getDb();
  if (!db) return false;
  await db.delete(errorEntries).where(eq(errorEntries.id, id));
  return true;
}

// Editorial Topics
export async function getEditorialTopics(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(editorialTopics).where(eq(editorialTopics.userId, userId));
}

export async function addEditorialTopic(userId: number, data: Omit<InsertEditorialTopic, 'userId'>) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(editorialTopics).values({ userId, ...data } as InsertEditorialTopic);
  return data;
}

export async function updateEditorialTopic(id: string, data: Partial<InsertEditorialTopic>) {
  const db = await getDb();
  if (!db) return null;
  await db.update(editorialTopics).set(data).where(eq(editorialTopics.id, id));
  return data;
}

export async function deleteEditorialTopic(id: string) {
  const db = await getDb();
  if (!db) return false;
  await db.delete(editorialTopics).where(eq(editorialTopics.id, id));
  return true;
}

// Weekend Blocks
export async function getWeekendBlocks(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(weekendBlocks).where(eq(weekendBlocks.userId, userId));
}

export async function addWeekendBlock(userId: number, data: Omit<InsertWeekendBlock, 'userId'>) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(weekendBlocks).values({ userId, ...data } as InsertWeekendBlock);
  return data;
}

// Arguments
export async function getArguments(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(argumentsTable).where(eq(argumentsTable.userId, userId));
}

export async function addArgument(userId: number, data: Omit<InsertArgument, 'userId'>) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(argumentsTable).values({ userId, ...data } as InsertArgument);
  return data;
}

export async function updateArgument(id: string, data: Partial<InsertArgument>) {
  const db = await getDb();
  if (!db) return null;
  await db.update(argumentsTable).set(data).where(eq(argumentsTable.id, id));
  return data;
}

export async function deleteArgument(id: string) {
  const db = await getDb();
  if (!db) return false;
  await db.delete(argumentsTable).where(eq(argumentsTable.id, id));
  return true;
}

// Exam Questions
export async function getExamQuestions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(examQuestions).where(eq(examQuestions.userId, userId));
}

export async function addExamQuestion(userId: number, data: Omit<InsertExamQuestion, 'userId'>) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(examQuestions).values({ userId, ...data } as InsertExamQuestion);
  return data;
}

export async function updateExamQuestion(id: string, data: Partial<InsertExamQuestion>) {
  const db = await getDb();
  if (!db) return null;
  await db.update(examQuestions).set(data).where(eq(examQuestions.id, id));
  return data;
}

export async function deleteExamQuestion(id: string) {
  const db = await getDb();
  if (!db) return false;
  await db.delete(examQuestions).where(eq(examQuestions.id, id));
  return true;
}

// Study Calendar
export async function getStudyCalendar(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(studyCalendar).where(eq(studyCalendar.userId, userId));
}

export async function addStudyCalendarDay(userId: number, data: Omit<InsertStudyCalendarDay, 'userId'>) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(studyCalendar).values({ userId, ...data } as InsertStudyCalendarDay);
  return data;
}

export async function updateStudyCalendarDay(id: string, data: Partial<InsertStudyCalendarDay>) {
  const db = await getDb();
  if (!db) return null;
  await db.update(studyCalendar).set(data).where(eq(studyCalendar.id, id));
  return data;
}
