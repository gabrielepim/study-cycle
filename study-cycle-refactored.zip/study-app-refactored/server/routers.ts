import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { srsRouter } from "./routers/srs";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Study Cycle Routers
  studyCycle: router({
    getCycleProgress: protectedProcedure.query(({ ctx }) =>
      db.getCycleProgress(ctx.user.id)
    ),
    upsertCycleProgress: protectedProcedure
      .input(z.object({
        currentSessionId: z.number().optional(),
        completedSessions: z.array(z.number()).optional(),
      }))
      .mutation(({ ctx, input }) =>
        db.upsertCycleProgress(ctx.user.id, input)
      ),
  }),

  productivity: router({
    getRecords: protectedProcedure.query(({ ctx }) =>
      db.getProductivityRecords(ctx.user.id)
    ),
    addRecord: protectedProcedure
      .input(z.object({
        id: z.string(),
        sessionId: z.number(),
        sessionName: z.string(),
        questionsAttempted: z.number(),
        questionsCorrect: z.number(),
        successRate: z.string(),
        duration: z.number(),
        focus: z.enum(["Teoria", "Questões", "Revisão"]).optional(),
      }))
      .mutation(({ ctx, input }) =>
        db.addProductivityRecord(ctx.user.id, input as any)
      ),
  }),

  errors: router({
    getEntries: protectedProcedure.query(({ ctx }) =>
      db.getErrorEntries(ctx.user.id)
    ),
    addEntry: protectedProcedure
      .input(z.object({
        id: z.string(),
        subject: z.string(),
        description: z.string(),
        errorType: z.enum(["Lei Seca", "Atenção", "Teoria"]),
        category: z.enum(["Legislação", "Geral"]),
        lastPage: z.string().optional(),
      }))
      .mutation(({ ctx, input }) =>
        db.addErrorEntry(ctx.user.id, input as any)
      ),
    deleteEntry: protectedProcedure
      .input(z.object({ id: z.string() }))
      .mutation(({ input }) =>
        db.deleteErrorEntry(input.id)
      ),
  }),

  editorial: router({
    getTopics: protectedProcedure.query(({ ctx }) =>
      db.getEditorialTopics(ctx.user.id)
    ),
    addTopic: protectedProcedure
      .input(z.object({
        id: z.string(),
        subject: z.string(),
        topic: z.string(),
        subtopics: z.array(z.any()).default([]),
        freshness: z.enum(["green", "yellow", "red"]).default("red"),
      }))
      .mutation(({ ctx, input }) =>
        db.addEditorialTopic(ctx.user.id, input as any)
      ),
    updateTopic: protectedProcedure
      .input(z.object({
        id: z.string(),
        data: z.any(),
      }))
      .mutation(({ input }) =>
        db.updateEditorialTopic(input.id, input.data)
      ),
    deleteTopic: protectedProcedure
      .input(z.object({ id: z.string() }))
      .mutation(({ input }) =>
        db.deleteEditorialTopic(input.id)
      ),
  }),

  arguments: router({
    getAll: protectedProcedure.query(({ ctx }) =>
      db.getArguments(ctx.user.id)
    ),
    add: protectedProcedure
      .input(z.object({
        id: z.string(),
        subject: z.enum(["Relações Públicas", "Legislação", "Geral"]),
        title: z.string(),
        content: z.string(),
        tags: z.array(z.string()).default([]),
      }))
      .mutation(({ ctx, input }) =>
        db.addArgument(ctx.user.id, input as any)
      ),
    update: protectedProcedure
      .input(z.object({
        id: z.string(),
        data: z.any(),
      }))
      .mutation(({ input }) =>
        db.updateArgument(input.id, input.data)
      ),
    delete: protectedProcedure
      .input(z.object({ id: z.string() }))
      .mutation(({ input }) =>
        db.deleteArgument(input.id)
      ),
  }),

  examQuestions: router({
    getAll: protectedProcedure.query(({ ctx }) =>
      db.getExamQuestions(ctx.user.id)
    ),
    add: protectedProcedure
      .input(z.object({
        id: z.string(),
        organ: z.string().optional(),
        banca: z.string().optional(),
        year: z.number().optional(),
        subject: z.string(),
        enunciation: z.string(),
        alternatives: z.object({
          a: z.string(),
          b: z.string(),
          c: z.string(),
          d: z.string(),
          e: z.string(),
        }),
        correctAnswer: z.enum(["a", "b", "c", "d", "e"]),
        questionType: z.enum(["Múltipla Escolha", "Verdadeiro/Falso", "Discursiva"]),
        errorTags: z.array(z.string()).default([]),
        comments: z.string().optional(),
      }))
      .mutation(({ ctx, input }) =>
        db.addExamQuestion(ctx.user.id, input as any)
      ),
    update: protectedProcedure
      .input(z.object({
        id: z.string(),
        data: z.any(),
      }))
      .mutation(({ input }) =>
        db.updateExamQuestion(input.id, input.data)
      ),
    delete: protectedProcedure
      .input(z.object({ id: z.string() }))
      .mutation(({ input }) =>
        db.deleteExamQuestion(input.id)
      ),
  }),

  calendar: router({
    getAll: protectedProcedure.query(({ ctx }) =>
      db.getStudyCalendar(ctx.user.id)
    ),
    addDay: protectedProcedure
      .input(z.object({
        id: z.string(),
        date: z.string(),
        studied: z.boolean().default(false),
        duration: z.number().default(0),
        sessionType: z.enum(["Ciclo", "Discursiva", "Revisão Geral"]).optional(),
      }))
      .mutation(({ ctx, input }) =>
        db.addStudyCalendarDay(ctx.user.id, input as any)
      ),
    updateDay: protectedProcedure
      .input(z.object({
        id: z.string(),
        data: z.any(),
      }))
      .mutation(({ input }) =>
        db.updateStudyCalendarDay(input.id, input.data)
      ),
  }),

  // SRS Router (Spaced Repetition System)
  srs: srsRouter,
});

export type AppRouter = typeof appRouter;

